#import "ControlFactory.h"

@implementation ControlFactory

- (void)createControlPair:(BOOL)isSwitch index:(int)idx title:(NSString *)title subtitle:(NSString *)subtitle frame:(CGRect)frame inView:(UIView *)menuView GuiColor:(UIColor *)GuiColor {
    if (isSwitch) {
        UISwitch *switch1 = [self createSwitchWith2Text:title text2:subtitle frame:frame inView:menuView action:@selector(SWTapped) hideLabel:false GuiColor:GuiColor];
        UISwitch *switch2 = [self createSwitchWith2Text:title text2:subtitle frame:frame inView:menuView action:@selector(SWTapped1) hideLabel:true GuiColor:GuiColor];

    } else {
        CustomCheckbox *checkbox1 = [self createCheckboxWithFrame:frame title:title size:10 color:GuiColor action:@selector(CheckboxTapped) hideLabel:false];
        CustomCheckbox *checkbox2 = [self createCheckboxWithFrame:frame title:title size:10 color:[UIColor clearColor] action:@selector(CheckboxTapped1) hideLabel:true];
        [menuView addSubview:checkbox1];
        [menuView addSubview:checkbox2];
    }
}

- (UILabel *)createLabelWithText:(NSString *)text size:(int)size color:(UIColor *)color numberOfLines:(int)numberOfLines frame:(CGRect)frame {
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.textColor = color;
    label.text = text;
    label.font = [UIFont systemFontOfSize:size];
    label.numberOfLines = numberOfLines;
    label.textAlignment = NSTextAlignmentLeft;
    return label;
}

- (UISwitch *)createSwitchWithText:(NSString *)text frame:(CGRect)frame inView:(UIView *)view action:(SEL)action hideLabel:(BOOL)hideLabel GuiColor:(UIColor *)GuiColor {
    UISwitch *switchControl = [[UISwitch alloc] initWithFrame:frame];
    if (!hideLabel) {
        switchControl.onTintColor = GuiColor;
        [switchControl addTarget:self action:action forControlEvents:UIControlEventValueChanged];
        switchControl.transform = CGAffineTransformMakeScale(0.8, 0.8);
        [view addSubview:switchControl];
        UILabel *label = [self createLabelWithText:text size:14 color:[UIColor whiteColor] numberOfLines:1 frame:CGRectMake(frame.origin.x + 50, frame.origin.y - 5, 130, 40)];
        [view addSubview:label];
    } else {
        switchControl.thumbTintColor = [UIColor clearColor];
        switchControl.onTintColor = [UIColor clearColor];
        [switchControl addTarget:self action:action forControlEvents:UIControlEventValueChanged];
        switchControl.transform = CGAffineTransformMakeScale(0.8, 0.8);
        [view addSubview:switchControl];
    }
    return switchControl; 
}

- (UISwitch *)createSwitchWith2Text:(NSString *)text1 text2:(NSString *)text2 frame:(CGRect)frame inView:(UIView *)view action:(SEL)action hideLabel:(BOOL)hideLabel GuiColor:(UIColor *)GuiColor {
    UISwitch *switchControl = [[UISwitch alloc] initWithFrame:frame];
    if (!hideLabel) {
        switchControl.onTintColor = GuiColor;
        switchControl.tintColor = [UIColor colorWithWhite:0.39 alpha:0.73];
        [switchControl addTarget:self action:action forControlEvents:UIControlEventValueChanged];
        switchControl.transform = CGAffineTransformMakeScale(0.8, 0.8);
        [view addSubview:switchControl];
        UILabel *label1 = [self createLabelWithText:text1 size:12 color:[UIColor whiteColor] numberOfLines:1 frame:CGRectMake(frame.origin.x + 50, frame.origin.y, 130, 20)];
        [view addSubview:label1];
        UILabel *label2 = [self createLabelWithText:text2 size:8 color:[UIColor whiteColor] numberOfLines:1 frame:CGRectMake(frame.origin.x + 50, frame.origin.y + 12, 130, 20)];
        [view addSubview:label2];
    } else {
        switchControl.onTintColor = [UIColor clearColor];
        switchControl.tintColor = [UIColor clearColor];
        switchControl.thumbTintColor = [UIColor clearColor];
        [switchControl addTarget:self action:action forControlEvents:UIControlEventValueChanged];
        switchControl.transform = CGAffineTransformMakeScale(0.8, 0.8);
        [view addSubview:switchControl];
    }
    return switchControl; 
}

- (CustomCheckbox *)createCheckboxWithFrame:(CGRect)frame title:(NSString *)title size:(int)size color:(UIColor *)color action:(SEL)action hideLabel:(BOOL)hideLabel {
    CustomCheckbox *checkbox = [[CustomCheckbox alloc] initWithFrame:frame title:title size:size color:color];
    checkbox.backgroundColorUnchecked = [UIColor clearColor]; 
    checkbox.backgroundColorChecked = [UIColor clearColor];
    if (!hideLabel) {
        checkbox.borderColor = color;
        checkbox.label.textColor = [UIColor whiteColor];
    } else {
        checkbox.borderColor = [UIColor clearColor];
        checkbox.label.textColor = [UIColor clearColor];
    }
    [checkbox addTarget:self action:action forControlEvents:UIControlEventValueChanged];
    
    return checkbox;
}
- (CAShapeLayer*)drawLineAtPosition:(CGPoint)position width:(CGFloat)width height:(CGFloat)height color:(UIColor *)color inView:(UIView *)view {
    CAShapeLayer *lineLayer = [CAShapeLayer layer];
    lineLayer.frame = CGRectMake(position.x, position.y, width, height); 
    lineLayer.backgroundColor = [UIColor clearColor].CGColor;

    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(0, 0)];
    [path addLineToPoint:CGPointMake(width, 0)];

    lineLayer.path = path.CGPath;
    lineLayer.strokeColor = color.CGColor; 
    lineLayer.lineWidth = height; 
    [view.layer addSublayer:lineLayer];
	return lineLayer;
}
- (NSDictionary *)createCustomSliderAtPosition:(CGPoint)position withSize:(CGSize)size minimumValue:(float)minValue maximumValue:(float)maxValue
                    value:(float)initialValue selector:(SEL)selector format:(NSString *)formatString inView:(UIView *)menuView hideLabel:(BOOL)hideLabel GuiColor:(UIColor *)GuiColor {
    
    UIView *sliderBackground = [[UIView alloc] initWithFrame:CGRectMake(position.x, position.y, size.width, size.height)];
    if(!hideLabel){
        sliderBackground.backgroundColor = [UIColor lightGrayColor];
    }
    else{
        sliderBackground.backgroundColor = [UIColor clearColor];
    }
    sliderBackground.layer.cornerRadius = size.height / 2;
    [menuView addSubview:sliderBackground];

    UISlider *floatSlider = [[UISlider alloc] initWithFrame:CGRectMake(position.x, position.y, size.width, size.height)];
    floatSlider.minimumValue = minValue;
    floatSlider.maximumValue = maxValue;
    floatSlider.value = initialValue > 0 ? initialValue : minValue;
    [floatSlider setMinimumTrackTintColor:[UIColor clearColor]];
    [floatSlider setMaximumTrackTintColor:[UIColor clearColor]];
    if(!hideLabel){
        [floatSlider setThumbTintColor:GuiColor];
    }
    else{
        [floatSlider setThumbTintColor:[UIColor clearColor]];
    }
    [menuView addSubview:floatSlider];
    
    UILabel *flabel = [[UILabel alloc] initWithFrame:CGRectMake(position.x, position.y, size.width, size.height)];
    flabel.textColor = [UIColor whiteColor];
    flabel.textAlignment = NSTextAlignmentCenter;
    flabel.text = [NSString stringWithFormat:formatString, floatSlider.value];
    [floatSlider addTarget:self action:selector forControlEvents:UIControlEventValueChanged];
    if(!hideLabel){
        [menuView addSubview:flabel];
    }
    
    return @{@"slider": floatSlider, @"label": flabel};
}
- (UIButton *)createButtonWithType:(UIButtonType)type frame:(CGRect)frame imageName:(NSString *)imageName action:(SEL)action hideLabel:(BOOL)hideLabel GuiColor:(UIColor *)GuiColor {
    UIButton *button = [UIButton buttonWithType:type];
    button.frame = frame;
    UIImageSymbolConfiguration *config = [UIImageSymbolConfiguration configurationWithPointSize:35.0 weight:UIImageSymbolWeightRegular scale:UIImageSymbolScaleDefault];
    UIImage *image = [UIImage systemImageNamed:imageName withConfiguration:config];
    [button setImage:image forState:UIControlStateNormal];  
    if(!hideLabel){
        [button setTintColor:GuiColor];
    }
    else{
        [button setTintColor:[UIColor clearColor]];
    }
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}
@end