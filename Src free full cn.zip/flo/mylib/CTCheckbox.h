#import <UIKit/UIKit.h>

@interface CustomCheckbox : UIButton

@property (nonatomic, assign) BOOL checked;
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UIColor *checkboxColor;
@property (nonatomic, strong) UIColor *backgroundColorUnchecked;
@property (nonatomic, strong) UIColor *backgroundColorChecked; 
@property (nonatomic, strong) UIColor *borderColor;
@property (nonatomic, strong) UIColor *TextColor;
@property (nonatomic, strong) CAShapeLayer *checkLayer;
- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title size:(int)sizeText color:(UIColor *)color;

@end