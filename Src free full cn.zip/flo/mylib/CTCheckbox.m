#import "CTCheckbox.h"

@implementation CustomCheckbox

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title size:(int)sizeText color:(UIColor *)color {
    self = [super initWithFrame:frame];
    if (self) {
        self.checked = NO;
        self.checkboxColor = color;
        self.backgroundColorUnchecked = [UIColor clearColor];
        self.backgroundColorChecked = [UIColor clearColor];
		self.TextColor = [UIColor whiteColor];
        // Tạo label
        self.label = [[UILabel alloc] initWithFrame:CGRectMake(frame.size.width + 5, (frame.size.height - 20) / 2, 200.0, 20.0)];
        self.label.text = title;
        self.label.textColor = self.TextColor;
        self.label.font = [UIFont systemFontOfSize:sizeText];
        [self addSubview:self.label];
        [self addTarget:self action:@selector(toggleChecked) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)toggleChecked {
    self.checked = !self.checked;
    [self setNeedsDisplay];
    [self sendActionsForControlEvents:UIControlEventValueChanged];
}

- (void)drawRect:(CGRect)rect {
    self.backgroundColor = self.checked ? self.backgroundColorChecked : self.backgroundColorUnchecked;
    UIBezierPath *roundedRectanglePath = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, rect.size.width, rect.size.height) cornerRadius:4];
    [self.borderColor setStroke];
    roundedRectanglePath.lineWidth = 2; 
    roundedRectanglePath.lineJoinStyle = kCGLineJoinRound;
    [roundedRectanglePath stroke];
    if (self.checked) {
        UIBezierPath *checkmarkPath = [UIBezierPath bezierPath];
        [checkmarkPath moveToPoint:CGPointMake(rect.size.width * 0.25, rect.size.height * 0.5)];
        [checkmarkPath addLineToPoint:CGPointMake(rect.size.width * 0.4, rect.size.height * 0.75)];
        [checkmarkPath addLineToPoint:CGPointMake(rect.size.width * 0.75, rect.size.height * 0.25)];
        [self.checkboxColor setStroke];
        checkmarkPath.lineWidth = 2;
        [checkmarkPath stroke];
		/*CGRect squareRect = CGRectMake(rect.size.width * 0.25, rect.size.height * 0.25, rect.size.width * 0.5, rect.size.height * 0.5); 
        UIBezierPath *squarePath = [UIBezierPath bezierPathWithRect:squareRect];
        [self.checkboxColor setFill]; 
        [squarePath fill]; */
    }
}

@end