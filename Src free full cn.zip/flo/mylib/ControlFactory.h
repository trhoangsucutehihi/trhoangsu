#import <UIKit/UIKit.h>
#import "../mylib/CTCheckbox.h"
@interface ControlFactory : NSObject

- (void)createControlPair:(BOOL)isSwitch index:(int)idx title:(NSString *)title subtitle:(NSString *)subtitle frame:(CGRect)frame inView:(UIView *)menuView GuiColor:(UIColor *)GuiColor;
- (UILabel *)createLabelWithText:(NSString *)text size:(int)size color:(UIColor *)color numberOfLines:(int)numberOfLines frame:(CGRect)frame;
- (UISwitch *)createSwitchWithText:(NSString *)text frame:(CGRect)frame inView:(UIView *)view action:(SEL)action hideLabel:(BOOL)hideLabel GuiColor:(UIColor *)GuiColor;
- (UISwitch *)createSwitchWith2Text:(NSString *)text1 text2:(NSString *)text2 frame:(CGRect)frame inView:(UIView *)view action:(SEL)action hideLabel:(BOOL)hideLabel GuiColor:(UIColor *)GuiColor;
- (CustomCheckbox *)createCheckboxWithFrame:(CGRect)frame title:(NSString *)title size:(int)size color:(UIColor *)color action:(SEL)action hideLabel:(BOOL)hideLabel;
- (NSDictionary *)createCustomSliderAtPosition:(CGPoint)position withSize:(CGSize)size minimumValue:(float)minValue maximumValue:(float)maxValue
                    value:(float)initialValue selector:(SEL)selector format:(NSString *)formatString inView:(UIView *)menuView hideLabel:(BOOL)hideLabel GuiColor:(UIColor *)GuiColor;
- (CAShapeLayer*)drawLineAtPosition:(CGPoint)position width:(CGFloat)width height:(CGFloat)height color:(UIColor *)color inView:(UIView *)view;
- (UIButton *)createButtonWithType:(UIButtonType)type frame:(CGRect)frame imageName:(NSString *)imageName action:(SEL)action hideLabel:(BOOL)hideLabel GuiColor:(UIColor *)GuiColor;
@end
