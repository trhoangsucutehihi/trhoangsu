#ifndef THPATCHMEM_H
#define THPATCHMEM_H

#include <cstddef> 
#include <cstdint> 
#include <mach/mach.h> 

class THPatchMem {
public:
    // Phương thức để patch bộ nhớ
    bool patchMemory(void* address, uint8_t* buffer, size_t bufferSize);
    uint8_t* ReadMemAtAddr(unsigned long long address, size_t size);
};

#endif // THPATCHMEM_H