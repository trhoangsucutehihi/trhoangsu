#include "Include.h"
set<void*> enemyLinkerBP;
set<int> enemyConfigID;
typedef struct {
    uint16_t m_equipID;       
    uint32_t m_amount; 
    uint32_t m_maxAmount; 
} stEquipInfo;

// Trong Overlay.h
int (*GetEquipActiveSkillCD)(void* instance, int equipID);
void* (*GetExistEquipInfoSet)(void* instance);
void* *(*get_ActiveBattleLogic)();
void* (*get_gameActorMgr)(void* instance);
void* (*GetEquipInfo)(void* instance,int equipindex);
monoList<void**> *(*GetAllMonsters)(void* instance);
monoList<void**> *(*Lactorroot_GetAllMonsters)(void* instance);
void* *(*get_actorManager)();

int (*GetCurrentActiveEquipId)(void* instance);
int (*ValuePropertyComponent_get_actorEp)(void *instance);
int (*ValuePropertyComponent_get_actorEpTotal)(void *instance);
int (*ValuePropertyComponent_get_actorSoulLevel)(void *instance);
VInt3 (*LActorRoot_get_location)(void *instance);
VInt3 (*LActorRoot_get_forward)(void *instance);
void* (*LActorRoot_get_PlayerMovement)(void* instance);
uintptr_t (*LActorRoot_LHeroWrapper)(void *instance);
int (*LActorRoot_COM_PLAYERCAMP)(void *instance);
bool (*LActorRoot_get_bActive)(void *instance);
int (*LActorRoot_get_ObjID)(void *instance);
bool (*LObjWrapper_get_IsDeadState)(void *instance);
bool (*LObjWrapper_IsAutoAI)(void *instance);
int (*ValuePropertyComponent_get_actorHp)(void *instance);
int (*ValuePropertyComponent_get_actorHpTotal)(void *instance);
int (*ValueLinkerComponent_get_actorEp)(void *instance);
int (*ValueLinkerComponent_get_actorEpTotal)(void *instance);
int (*ValueLinkerComponent_get_actorSoulLevel)(void *instance);
void *(*ValuePropertyComponent_BaseEnergyLogic)(void *instance);
int (*ActorLinker_COM_PLAYERCAMP)(void *instance);
bool (*ActorLinker_IsHostPlayer)(void *instance);
bool (*ActorLinker_IsHostCamp)(void *instance);
int (*ActorLinker_ActorTypeDef)(void *instance);
Vector3 (*ActorLinker_getPosition)(void *instance);
int (*ActorLinker_get_ObjID)(void *instance);
int (*ActorLinker_get_ConfigID)(void *instance);
bool (*ActorLinker_get_bVisible)(void *instance);
void* (*AsHero)(void* instance);	
void* (*LactorRoot_AsHero)(void* instance);
void (*LEquipComponent_BuyEquip)(void* instance,int equipID,bool InIsQuicklyBuy,bool InAutobuy);
void (*LEquipComponent_SellEquip)(void* instance,int equipindex);
void (*LEquipComponent_updateLogic)(void* instance,int deltaTime);
Array<void*> * (*LEquipComponent_GetEquips)(void* instance);
Dictionary<int,void*> *(*get_EquipPassiveSkillInfoMap)(void* instance);
void (*LEquipComponent_UpdateEquipEffect)(void* instance);
void (*SetPlayerName)(void* instance, MonoString* playerName, MonoString* prefixName, bool isGuideLevel, MonoString* customName);
void (*HostSetPlayerName)(void *instance, MonoString* playerName, bool isHostPlayer);
Vector2 (*GetMMFianlScreenPos)(void *instance);
Vector2 (*GetBMFianlScreenPos)(void *instance);
Vector2 (*get_mmFinalScreenSize)(void *instance);
Vector2 (*get_bmFinalScreenSize)(void *instance);
bool (*Is3V3Minimap)(void *instance);
int (*get_CurMapType)(void *instance);
void (*Update_Minimap)(void *instance);
bool (*RequestUseSkillSlot)(void* instance,int slot, int mode, uint objID , int subSkillID);
void (*ReadyUseSkillSlot)(void* instance,int slot,bool bForce);
bool (*CanRequestSkill)(void* instance,int slot);
bool (*Reqskill)(void *ins);
bool (*Reqskill2)(void *ins,bool bForce);
int (*get_speed)(void* instance);
int (*ActorLinker_get_playerId)(void *instance);
void (*StopInput)(void* instance);
void* (*GetSkillSlot)(void* instance, int skillslottype);
void* (*get_RealSkillObj)(void* instance);
void* (*get_CurSkillCD)(void* instance);
void (*SkillSlot2_UpdateLogic)(void* instance, int deltatime);

Vector2 MinimapSize;
Vector2 BigmapSize;
Vector2 minimapPos;
Vector2 bigmapPos;
Vector2 MinimapOrg;
float MinimapCenterX;
float MinimapCenterY;
float BigmapCenterX;
float BigmapCenterY;
float MinimapScale;
int MapType;
Vector3 CurrentPosition = Vector3::zero();
Vector3 AimVector = Vector3::zero();
Vector3 AimVector2 = Vector3::zero();
ImVec2 rootPos_Hoa = ImVec2(0,0);
bool isFliped = false;
bool isNormal5v5mode = false;
bool Trainningmode = false;
bool is3V3Minimap = false;
bool bLowestHp = false; //Lowest Hp
bool bLowestHpPercent = false; //Lowest Hp Percent
bool bClosestEnemy = false; //Closest Enemy
bool bClosestEnemyView = false; //Closest Enemy View
float myHpPercent = 0;
float myEpPercent = 0;
float Rangeskill1 = 0;
float Rangeskill2 = 0;
float Rangeskill3 = 0;
float speedSkill = 3.63;
float speedSkill2 = 0;
float speedSkill3 = 0;
float BulletSpeed = 0;
void* ismine = nullptr;
bool activeaim = false;
int tagid;
void* Lactorroot_Ismine;
void *Lactor = nullptr;

void *Req5 = nullptr;
void *Req0 = nullptr;
void *Req1 = nullptr;
void *Req2 = nullptr;
void *Req3 = nullptr;
void *Req9 = nullptr;
vector<int> targetConfigIDs = {196, 157, 175, 108, 174, 521, 195, 529, 545};
uint16_t ItemID[6];
void *BPinstance = nullptr;
int myObjID = 0;
void* MoveInstance = nullptr;
int floc2 = 0;
vector<Vector3> recentlyRemovedInstances;
const int MAX_REMOVED_INSTANCES = 30;
bool isCloseVector3(const Vector3& a, const Vector3& b, float tolerance = 0.1f) {
    return abs(a.x - b.x) < tolerance &&
           abs(a.y - b.y) < tolerance &&
           abs(a.z - b.z) < tolerance;
}


MonoString* (*_RemoveSpace)(void *instance,MonoString* inputname);
MonoString* RemoveSpace(void *instance,MonoString* inputname)
{
	if(instance != NULL)
	{
		if(boolUS[3])
		{
			return inputname;
		}
	}
	return _RemoveSpace(instance,inputname);
}

void addRemovedInstance(Vector3 instance) {
    for (const auto& existingInstance : recentlyRemovedInstances) {
        if (isCloseVector3(existingInstance, instance)) {
            return;
        }
    }
    if (recentlyRemovedInstances.size() >= MAX_REMOVED_INSTANCES) {
        recentlyRemovedInstances.erase(recentlyRemovedInstances.begin());
    }
    recentlyRemovedInstances.push_back(instance);
}
bool isInstanceRemoved(Vector3 instance) {
    for (const auto& removedInstance : recentlyRemovedInstances) {
        if (isCloseVector3(removedInstance, instance)) {
            return true;
        }
    }
    return false;
}
bool (*get_bMiniMapBgFlip)(void *instance);
bool (*IsNormal5v5mode)(void *instance);
int (*GetGameRoomType)(void* instance);
int roomtype = 0;
bool _get_bMiniMapBgFlip(void *instance){
    if(instance != NULL){
        isNormal5v5mode = IsNormal5v5mode(instance);
        roomtype = GetGameRoomType(instance);
    }
    return get_bMiniMapBgFlip(instance);
}

void _Update_Minimap(void *instance){
	if(instance != NULL)
    {   
        if(isFirst){
            MinimapOrg = GetMMFianlScreenPos(instance);
            isFirst = false;
        }
        if(!boolUS[21])
        { if(!giatriBool[13])
            {
                AntiHooK = true;
                AntiDo = true;
                thongbaohack();
                giatriBool[13] = true;
            }
        }
        else
        {
            AntiHooK = false;
            AntiDo = false;
            giatriBool[13] = false;
        }
        is3V3Minimap = Is3V3Minimap(instance);
        minimapPos = GetMMFianlScreenPos(instance); 
        bigmapPos = GetBMFianlScreenPos(instance);
        MapType = get_CurMapType(instance);
        float newScale = (float)5*(kScale+1)/14;
        if(kScale == 2 && kHeight < 500)
        {
            newScale = (float)5*(kScale+2)/14;
        }
        if(minimapPos.x>0)
        {
            MinimapScale = MinimapOrg.x/minimapPos.x;
            if(MinimapOrg.y/newScale > kHeight)
            {
                MinimapSize = get_mmFinalScreenSize(instance)/kScale;
                BigmapSize = get_bmFinalScreenSize(instance)/kScale;
                MinimapCenterX = (minimapPos.x*MinimapScale)/kScale;
                MinimapCenterY = (gHeight - minimapPos.y*MinimapScale)/kScale;
                BigmapCenterX = (bigmapPos.x*MinimapScale)/kScale;
                BigmapCenterY = (gHeight - bigmapPos.y*MinimapScale)/kScale;
            }
            else
            {
                MinimapSize = get_mmFinalScreenSize(instance)/newScale;
                BigmapSize = get_bmFinalScreenSize(instance)/newScale;
                MinimapCenterX = minimapPos.x/newScale;
                MinimapCenterY = kHeight - minimapPos.y/newScale;
                BigmapCenterX = bigmapPos.x/newScale;
                BigmapCenterY = kHeight - bigmapPos.y/newScale;
            }
        }
        
    }
	return Update_Minimap(instance);
}
void (*ActorLinker_ActorDestroy)(void *instance);
void _ActorLinker_ActorDestroy(void *instance) {
    if (instance != NULL) {
        ActorLinker_ActorDestroy(instance);
        ActorLinker_enemy->removeEnemyGivenObject(instance);
        Flo_Enemy->removeEnemyGivenObject(instance);
        if (espManager->MyPlayer == instance) {
            espManager->MyPlayer = NULL;
        }
    }
}
void (*LActorRoot_ActorDestroy)(void *instance, bool bTriggerEvent);
void _LActorRoot_ActorDestroy(void *instance, bool bTriggerEvent) {
    if (instance != NULL) {
        LActorRoot_ActorDestroy(instance, bTriggerEvent);
        espManager->removeEnemyGivenObject(instance);
        Flo_Enemy->removeEnemyGivenObject(instance);
    }
}
void (*ActorLinker_Update)(void *instance);
int* SkillControlAll(void* instance)
{
    void* SkillControl = AsHero(instance);
    int* cooldowns = (int*)malloc(5 * sizeof(int));
    if(SkillControl != NULL)
    {
        //showcd        
        int skill4 = *(int*) ((uint64_t)SkillControl + ESP[39]);
        uintptr_t Skill1Cd = (int)ceil(*(int *)((uint64_t)SkillControl + ESP[36] + ESP[40] - oxoranyoffset("0x10")) / 1000.0);
        uintptr_t Skill2Cd = (int)ceil(*(int *) ((uint64_t)SkillControl + ESP[37] + ESP[40] - oxoranyoffset("0x10")) / 1000.0);
        uintptr_t Skill3Cd = (int)ceil(*(int *) ((uint64_t)SkillControl + ESP[38] + ESP[40] - oxoranyoffset("0x10")) / 1000.0);
        uintptr_t Skill4Cd = (int)ceil(*(int *) ((uint64_t)SkillControl + ESP[39] + ESP[40] - oxoranyoffset("0x10")) / 1000.0);
        cooldowns[0] = Skill1Cd;
        cooldowns[1] = Skill2Cd;
        cooldowns[2] = Skill3Cd;
        cooldowns[3] = Skill4Cd;
        cooldowns[4] = skill4;
        return cooldowns;
    }
    free(cooldowns);
    return NULL;
}
void _ActorLinker_Update(void *instance) {
    if (instance != NULL) {
        void* SkillControl = AsHero(instance);
        void* HudControl = *(void**) ((uintptr_t)instance + ESP[12]);
        if (HudControl != NULL && SkillControl != NULL) {
            int* cooldowns = SkillControlAll(instance);
            if (boolUS[1] && cooldowns != NULL) 
            {

                if(instance != NULL && cooldowns != NULL && NameMode == 1)
                {
                    giatriBool[14] = true;
                    int cd1 = cooldowns[0];
                    int cd2 = cooldowns[1];
                    int cd3 = cooldowns[2];
                    int cd4 = cooldowns[3];
                    string openSk = "("; // Bắt đầu
                    string closeSk = ")  "; // Kết thúc
                    string sk1 = to_string(cd1);
                    string sk2 = to_string(cd2);
                    string sk3 = to_string(cd3);
                    string sk4 = to_string(cd4);
                    string ShowSkill = openSk + sk1 + closeSk + openSk + sk2 + closeSk + openSk + sk3 + closeSk;
                    string ShowSkill2 = openSk + sk4 + closeSk;
                    const char *str1 = ShowSkill.c_str();
                    const char *str2 = ShowSkill2.c_str();
                    MonoString *playerName = (MonoString*)CreateMonoString(str1);
                    MonoString *prefixName = (MonoString*)CreateMonoString(str2);
                    MonoString *customName = (MonoString*)CreateMonoString("");
                    SetPlayerName(HudControl, playerName, prefixName, false, customName);
                    giatriInt[1] = 0;
                }
                else if(instance != NULL && cooldowns != NULL && NameMode == 2) 
                {
                    giatriBool[14] = true;
                    NSString *combinedName = [NSString stringWithFormat:@"%@", FieldName[0].text];
                    const char *name = [combinedName UTF8String];
                    MonoString *playerName = (MonoString*)CreateMonoString(name);
                    MonoString *prefixName = (MonoString*)CreateMonoString("");
                    MonoString *customName = (MonoString*)CreateMonoString("");
                    SetPlayerName(HudControl, playerName, prefixName, false, customName);
                    giatriInt[1] = 0;
                }
                else if(instance != NULL && cooldowns != NULL && NameMode == 0) 
                {
                    if(giatriBool[14])
                    {
                        giatriBool[14] = false;
                        
                        for (const auto& pair : nameORG) {
                            
                            NSString *playerNameNSString = [NSString stringWithUTF8String:(pair.second).c_str()];
                            const char *name = [playerNameNSString UTF8String];
                            MonoString* Nameplayer = (MonoString*)CreateMonoString(name);
                            MonoString *customName = (MonoString*)CreateMonoString("");
                            SetPlayerName((void*)pair.first, Nameplayer, (MonoString*)CreateMonoString(""), false, customName);
                            giatriInt[1] = 0;
                        }
                    }
                }
            }
            free(cooldowns);
        }
        ActorLinker_Update(instance);
        if (ActorLinker_ActorTypeDef(instance) == 0) {
            bool found = false;
            void* ObjLinker = *(void**)((uintptr_t)instance + ESP[41]);
            if (!ObjLinker) return;
            int ConfigID = *(int*)((uintptr_t)ObjLinker + ESP[85]); 
            if (!ConfigID) return;
            for (const auto& pair : nameHostORG) 
            {
                if (pair.first == (uintptr_t)instance) 
                {
                    found = true;
                    break;
                }
            }
            if (!found) {
                HeroData heroData = findHeroById(ConfigID);
                string stdString = string(heroData.name);
                nameHostORG.emplace_back((uintptr_t)instance, stdString);
            }
            if (instance != NULL && ObjLinker != NULL && ConfigID != NULL && boolUS[1] && NameMode == 3) 
            {
                if(nameORG.size() == nameHostORG.size())
                {
                    if(giatriInt[0] < nameORG.size() && giatriInt[1] < 5)
                    {
                        const char *name = (nameHostORG[giatriInt[0]].second).c_str();
                        MonoString* Nameplayer = (MonoString*)CreateMonoString(name);
                        SetPlayerName((void*)nameORG[giatriInt[0]].first, Nameplayer, (MonoString*)CreateMonoString(""), false, (MonoString*)CreateMonoString(""));
                        giatriInt[0]++;
                    }
                    else
                    {
                        if(giatriInt[1] < 5)
                            giatriInt[1]++;
                        giatriInt[0] = 0;
                    }
                }
            }
            if (ActorLinker_IsHostPlayer(instance) == true) {
                espManager->tryAddMyPlayer(instance);
                Lactor = instance; 
                myObjID = ActorLinker_get_ObjID(instance);
                int team = ActorLinker_COM_PLAYERCAMP(instance);
                if(team == 2){
                    isFliped = true;}
                else {
                    isFliped = false;}
            } else {
                if (espManager->MyPlayer != NULL) {
                    if (ActorLinker_COM_PLAYERCAMP(espManager->MyPlayer) != ActorLinker_COM_PLAYERCAMP(instance)) {
                        ActorLinker_enemy->tryAddEnemy(instance);
                    }
                }
            }
        }
        if (ActorLinker_ActorTypeDef(instance) == 4 )
         {
            if (ActorLinker_IsHostCamp(instance) && espManager->MyPlayer != NULL && ActorLinker_get_ObjID(instance) != 0 && ActorLinker_get_playerId(instance) != 10001 && ActorLinker_get_playerId(instance) != 0 ) 
            {
                Vector3 MP = ActorLinker_getPosition(espManager->MyPlayer);
                Vector3 HP = ActorLinker_getPosition(instance);
                float Dis = Vector3::Distance(MP, HP);
                if(Dis > 1.8f && Dis < 12 && HP.y < 0.3)
                {
                    Flo_Enemy->tryAddEnemy(instance);
                }
                else 
                {
                    Flo_Enemy->removeEnemyGivenObject(instance);
                    addRemovedInstance(HP);
                }
            }
        }
    }
}
int dem(int num) {
    int div = 1, num1 = num;
    while (num1 != 0) {
        num1 = num1 / 10;
        div = div * 10;
    }
    return div;
}

Vector3 VInt2Vector(VInt3 location, VInt3 forward){
    return Vector3((float)(location.X*dem(forward.X)+forward.X)/(1000*dem(forward.X)), (float)(location.Y*dem(forward.Y)+forward.Y)/(1000*dem(forward.Y)), (float)(location.Z*dem(forward.Z)+forward.Z)/(1000*dem(forward.Z)));
}
Vector3 VIntVector(VInt3 location){
    return Vector3((float)(location.X)/(1000), (float)(location.Y)/(1000), (float)(location.Z)/(1000));
}

struct SkillInfo 
{
    int skillcd;
    int skillID;
};

SkillInfo Skillcd(void* instance, int slot)
{
    SkillInfo result = {0, 0};
    void* check = GetSkillSlot(instance,slot);
    if(check != NULL)
    {
        void* check20 = get_RealSkillObj(check);
        if(check20 != NULL)
        {
            result.skillcd = GetObscuredIntValue((uint64_t)check + ESP[58]);
            result.skillID = *(int *)((uint64_t)check20 + 0x28);

        }
    }
    return result;
}
int* SkillControlAll1(void* instance) {
    int* cooldowns = (int*)malloc(5 * sizeof(int));
    if (cooldowns == NULL) {
        return NULL;
    }

    SkillInfo skillInfo1 = Skillcd(instance, 1);
    SkillInfo skillInfo2 = Skillcd(instance, 2);
    SkillInfo skillInfo3 = Skillcd(instance, 3);
    SkillInfo skillInfo5 = Skillcd(instance, 5);

    cooldowns[0] = (int)ceil(skillInfo1.skillcd / 1000.0);
    cooldowns[1] = (int)ceil(skillInfo2.skillcd / 1000.0);
    cooldowns[2] = (int)ceil(skillInfo3.skillcd / 1000.0);
    cooldowns[3] = (int)ceil(skillInfo5.skillcd / 1000.0);
    cooldowns[4] = skillInfo5.skillID;

    return cooldowns;
}
void _SkillSlot2_UpdateLogic(void *instance,int delta){
	if(instance != NULL)
	{
     SkillSlot2_UpdateLogic(instance,delta);
     void*  crypticint = get_CurSkillCD(instance);
     if(crypticint!= NULL){

        ;}
     return;
	}
	return SkillSlot2_UpdateLogic(instance,delta);
}

void (*LActorRoot_UpdateLogic)(void *instance, int delta);  
void _LActorRoot_UpdateLogic(void *instance, int delta) {
    if (instance != NULL) {
        LActorRoot_UpdateLogic(instance, delta);
        if (espManager->MyPlayer != NULL) {
            if (LActorRoot_LHeroWrapper(instance) != 0 && LActorRoot_COM_PLAYERCAMP(instance) == ActorLinker_COM_PLAYERCAMP(espManager->MyPlayer)) 
            {
                espManager->tryAddEnemy(instance);
            }
            if(LActorRoot_get_ObjID(instance) == myObjID) {
                Lactorroot_Ismine = instance;
                void* EquipComponent = *(void**)((uint64_t)instance + ESP[45]);
                if(EquipComponent != NULL)
                {

                    auto ID = LEquipComponent_GetEquips(EquipComponent);
                    if(ID != NULL)
                    {
                        ItemID[0] = *(uint16_t*)((uint64_t)ID + 32);
                        ItemID[1] = *(uint16_t*)((uint64_t)ID + 44);
                        ItemID[2] = *(uint16_t*)((uint64_t)ID + 56);
                        ItemID[3] = *(uint16_t*)((uint64_t)ID + 68);
                        ItemID[4] = *(uint16_t*)((uint64_t)ID + 80);
                        ItemID[5] = *(uint16_t*)((uint64_t)ID + 92);
                    }
                    int GHSindex = -1;
                    int CBSindex = -1;
                    int LDMindex = -1;
                    int HTNindex = -1;
                    int NTindex = -1;
                    int QTindex = -1;
                    for(int i = 0; i < 6; i++)
                    {

                        if(ItemID[i] == 1337)
                        {
                            GHSindex = i;
                        }
                        else if(ItemID[i] == 1242)
                        {
                            CBSindex = i;
                        }
                        else if(ItemID[i] == 11271)
                        {
                            LDMindex = i;
                        }
                        else if(ItemID[i] == 1328)
                        {
                            HTNindex = i;
                        }
                        else if(ItemID[i] == 1340)
                        {
                            NTindex = i;
                        }
                        else if(ItemID[i] == 1227)
                        {
                            QTindex = i;
                        }
                    }
                    
if(boolUS[33]) // Sell 
                    {
                        if(GHSindex != -1)
                        {
                            LEquipComponent_SellEquip(EquipComponent,GHSindex);
                        }
                        if(CBSindex != -1)
                        {
                            LEquipComponent_SellEquip(EquipComponent,CBSindex);
                        }
                        if(LDMindex != -1)
                        {
                            LEquipComponent_SellEquip(EquipComponent,LDMindex);
                        }
                        if(HTNindex != -1)
                        {
                            LEquipComponent_SellEquip(EquipComponent,HTNindex);
                        }
                        if(NTindex != -1)
                        {
                            LEquipComponent_SellEquip(EquipComponent,NTindex);
                        }
                        if(QTindex != -1)
                        {
                            LEquipComponent_SellEquip(EquipComponent,QTindex);
                        }
                    }
                    
if(boolUS[34]) // Buy
                    {
    if (GHSindex != -1) {
        LEquipComponent_BuyEquip(EquipComponent, GHSindex, true, false); // Thay đổi đây
    }
    if (CBSindex != -1) {
        LEquipComponent_BuyEquip(EquipComponent, CBSindex, true, false); // Thay đổi đây
    }
    if (LDMindex != -1) {
        LEquipComponent_BuyEquip(EquipComponent, LDMindex, true, false); // Thay đổi đây
    }
    if (HTNindex != -1) {
        LEquipComponent_BuyEquip(EquipComponent, HTNindex, true, false); // Thay đổi đây
    }
    if (NTindex != -1) {
        LEquipComponent_BuyEquip(EquipComponent, NTindex, true, false); // Thay đổi đây
    }
    if (QTindex != -1) {
        LEquipComponent_BuyEquip(EquipComponent, QTindex, true, false); // Thay đổi đây
                                }
                    }
                }
            }
        }
    }
}

void DrawCircleHealth(ImVec2 position, int health, int max_health, float radius, int width) {
    float a_max = ((3.14159265359f * 2.0f));
    ImU32 healthColor = IM_COL32(45, 180, 45, 255);
    if (health <= (max_health * 0.6)) {
        healthColor = IM_COL32(180, 180, 45, 255);
    }
    if (health < (max_health * 0.3)) {
        healthColor = IM_COL32(180, 45, 45, 255);
    }
    ImGui::GetForegroundDrawList()->PathArcTo(position, radius, (-(a_max / 4.0f)) + (a_max / max_health) * (max_health - health), a_max - (a_max / 4.0f));
    ImGui::GetForegroundDrawList()->PathStroke(healthColor, ImDrawFlags_None, width);
}
void DrawCircleHealthMiniMap(ImDrawList *draw, ImVec2 position, int health, int max_health, float radius, float size) {

    if (health > max_health) {
        health = max_health;
    }
    if (health < 0) {
        health = 0;
    }

    float a_max = 6.28318530718f; // 2*PI
    ImU32 healthColor = IM_COL32(200, 0, 0, 255);
    ImU32 borderColor = IM_COL32(68, 18, 20, 255);

    // Vẽ viền tròn
    draw->PathArcTo(position, radius + size / 2, 0.0f, a_max);
//    draw->PathStroke(borderColor, ImDrawFlags_None, size + 1.5f);

    // Tính toán góc cho phần máu (tụt từ đỉnh xuống)
    float health_ratio = static_cast<float>(health) / max_health;
    float angle = a_max * health_ratio / 2.0f;

    // Đặt điểm bắt đầu vẽ ở đỉnh ( -PI/2 )
    float start_angle = a_max / 4.0f;

    // Vẽ phần máu
    
    // Vẽ hình tròn viền với độ dày đã giảm
    float borderThickness = size * 0.5f; // Giảm độ dày xuống còn một nửa (hoặc tùy ý)
    draw->PathStroke(borderColor, ImDrawFlags_None, borderThickness);
  
    // Vẽ phần máu
    draw->PathArcTo(position, radius + borderThickness, start_angle + angle, start_angle - angle);
    
//    draw->PathArcTo(position, radius + size/2 , start_angle + angle, start_angle - angle);
    draw->PathStroke(healthColor, ImDrawFlags_None, size);
}

void DrawCd(ImDrawList *draw, ImVec2 position, float size, ImU32 color, int cd) {
    string skill_cd = string(string("(").append(to_string(cd)).append(")"));
    auto textSize = ImGui::CalcTextSize(skill_cd.c_str(), 0, ((float) kHeight / 30.0f));
	if(cd > 0) {	
		draw->AddText(ImGui::GetFont(), ((float) kHeight / 30.0f), {position.x - (textSize.x / 2 ) , position.y - (textSize.y / 2) }, color, skill_cd.c_str());
	}
	else {
		draw->AddText(ImGui::GetFont(), ((float) kHeight / 30.0f), {position.x - (textSize.x / 2 ) , position.y - (textSize.y / 2) }, IM_COL32(128, 128, 128, 128), skill_cd.c_str());
	}
}
void RenderFilledRectangleWithText(ImDrawList *drawList,ImVec2 position, ImVec2 size, ImVec4 color, const char* text) {
    drawList->AddRectFilled({position.x - size.x / 2, position.y}, {position.x + size.x/2, position.y + size.y}, ImColor(color));
    ImVec2 textSize = ImGui::CalcTextSize(text, 0, ((float)kHeight/15.0f));
    ImVec2 textPosition = ImVec2(position.x - 1.5f*textSize.x, position.y - textSize.y/2);
    drawList->AddText(ImGui::GetFont(),((float)kHeight / 15.0f),textPosition, IM_COL32(255, 255, 255, 165), text);
}
void RenderFilledCircle(ImDrawList *drawList,ImVec2 center, float radius, ImU32 color, int segments = 12) {
    drawList->AddCircleFilled(center, radius, color, segments);
}
class Camera {
    public:
    static Camera *get_main() {
        Camera *(*get_main_) () = (Camera *(*)())getRealOffset(ESP[29]);
        return get_main_();
    }
	Vector3 WorldToViewportPoint(Vector3 position){
		Vector3 (*WorldToViewportPoint_)(Camera *camera, Vector3 position) = (Vector3 (*)(Camera *, Vector3))getRealOffset(ESP[31]);
		return WorldToViewportPoint_(this, position);
	}
    Vector3 WorldToScreenPoint(Vector3 position){
		Vector3 (*WorldToScreenPoint_)(Camera *camera, Vector3 position) = (Vector3 (*)(Camera *, Vector3))getRealOffset(ESP[30]);
		return WorldToScreenPoint_(this, position);
	}
};
struct Texture {
    id<MTLTexture> texture; 
    float height;
    float width;
};
id<MTLTexture> LoadImageFromMemory(id<MTLDevice> device, unsigned char* image_data, size_t image_size) {
    CFDataRef imageData = CFDataCreate(kCFAllocatorDefault, image_data, image_size);
    CGDataProviderRef dataProvider = CGDataProviderCreateWithCFData(imageData);
    CGImageRef cgImage = CGImageCreateWithPNGDataProvider(dataProvider, NULL, false, kCGRenderingIntentDefault);
    CFRelease(imageData);
    CGDataProviderRelease(dataProvider);
    if (!cgImage) {
        return nil;
    }
    NSError *error = nil;
    MTKTextureLoader *textureLoader = [[MTKTextureLoader alloc] initWithDevice:device];
    NSDictionary *options = @{MTKTextureLoaderOptionSRGB : @(NO)};
    id<MTLTexture> texture = [textureLoader newTextureWithCGImage:cgImage options:options error:&error];

    if (error) {
        CGImageRelease(cgImage);
        return nil;
    }
    CGImageRelease(cgImage);
    return texture;
}
vector<Texture> textures;

void AddTexturesFromImageData(id<MTLDevice> device) {
    for (const auto& heroData : heroArray) {
        Texture tex;
        tex.texture = LoadImageFromMemory(device, heroData.data, heroData.size);
        if(tex.texture == nil) continue;
        tex.width = tex.texture.width;
        tex.height = tex.texture.height;
        textures.push_back(tex);
    }
}
void Draw3dBox(ImDrawList *draw,Vector3 Transform, Camera * camera ,Texture &tex)
{
    const Vector3 positions[8] = {
        Transform + Vector3(0.6, 1.2, 0.6),
        Transform + Vector3(0.6, 0, 0.6),
        Transform + Vector3(-0.6, 0, 0.6),
        Transform + Vector3(-0.6, 1.2, 0.6),
        Transform + Vector3(0.6, 1.2, -0.6),
        Transform + Vector3(0.6, 0, -0.6),
        Transform + Vector3(-0.6, 0, -0.6),
        Transform + Vector3(-0.6, 1.2,-0.6)
    };
    float height = kHeight / 40;
    ImVec2 vector[8];
    for (int i = 0; i < 8; i++) {
        Vector3 pos = camera->WorldToViewportPoint(positions[i]);
        vector[i].x = pos.x*kWidth;
        vector[i].y = kHeight - pos.y*kHeight - height;
    }
    int lines[12][2] = {
        {0, 1}, {1, 2}, {0, 3}, {2, 3},
        {4, 5}, {5, 6}, {4, 7}, {6, 7},
        {0, 4}, {1, 5}, {2, 6}, {3, 7}
    };

    for (const auto& line : lines) {
        draw->AddLine(ImVec2(vector[line[0]].x, vector[line[0]].y), ImVec2(vector[line[1]].x, vector[line[1]].y), ImGui::GetColorU32(selectedImGuiColor[0]), 0.5f);
    }
    if(boolSW[10]){
        if(!isFliped){
            draw->AddImage((ImTextureID)(intptr_t)tex.texture, vector[3], vector[4], ImVec2(0, 0), ImVec2(1, 1));
        }
        else{
            draw->AddImage((ImTextureID)(intptr_t)tex.texture, vector[4], vector[3], ImVec2(0, 0), ImVec2(1, 1));
        }
    }
}


void DrawHealthBar(ImDrawList* draw, ImVec2 rootPos_Vec2, int EnemyHp, int EnemyHpTotal, int EnemyEp, int EnemyEpTotal, string heroname, int GetLever, float HPper) {
    ImVec2 namePos(rootPos_Vec2.x - 45, rootPos_Vec2.y + 22);

    float backgroundWidth = 90.0f;
    float healthBarWidth = backgroundWidth - 7.2f;
    float healthBarHeight = 4.3f;
    float ManaBarHeight = 2.5f;
    float manaBarWidth = backgroundWidth - 6.0f;

    ImVec2 nameSize = ImGui::CalcTextSize(heroname.c_str());
    ImVec2 levelSize = ImGui::CalcTextSize(to_string(GetLever).c_str());
    ImU32 healthColor = IM_COL32(0, 255, 0, 150);

    ImVec2 healthBarBackgroundPos(namePos.x + 7.2, namePos.y + 9);
    ImVec2 manaBarBackgroundPos(namePos.x + 6.0, namePos.y + 13);

 
    draw->AddRectFilled(healthBarBackgroundPos, ImVec2(healthBarBackgroundPos.x - 7.3 + backgroundWidth, healthBarBackgroundPos.y + healthBarHeight), IM_COL32(0, 0, 0, 150));
    
    draw->AddRectFilled(healthBarBackgroundPos, ImVec2(healthBarBackgroundPos.x + healthBarWidth * ((float)EnemyHp / (float)EnemyHpTotal), healthBarBackgroundPos.y + healthBarHeight), healthColor);

    // Vẽ thanh năng lượng
    draw->AddRectFilled(manaBarBackgroundPos, ImVec2(manaBarBackgroundPos.x - 6.1 + backgroundWidth, manaBarBackgroundPos.y + ManaBarHeight), IM_COL32(0, 0, 0, 150));
    if (EnemyEpTotal > 0) {
        draw->AddRectFilled(manaBarBackgroundPos, ImVec2(manaBarBackgroundPos.x + manaBarWidth * ((float)EnemyEp / (float)EnemyEpTotal), manaBarBackgroundPos.y + ManaBarHeight), IM_COL32(50, 104, 168, 255));
    } else {
        draw->AddRectFilled(manaBarBackgroundPos, ImVec2(manaBarBackgroundPos.x + manaBarWidth, manaBarBackgroundPos.y + ManaBarHeight), IM_COL32(255, 255, 255, 150));
    }
     // Vẽ nền đen
    ImVec2 rectPos = ImVec2(namePos.x, namePos.y-2);
    ImVec2 rectSize = ImVec2(namePos.x + backgroundWidth, namePos.y + nameSize.y-2);
    draw->AddRectFilled(rectPos, rectSize, IM_COL32(0, 0, 0, 150));

    // Vẽ hình thoi và level
    ImVec2 diamondCenter(namePos.x, namePos.y + levelSize.y / 2);
    float diamondSize = 12.0f;
    float borderThickness = 2.5f;

    // Viền trắng
    for (float i = 0; i < borderThickness; i++) {
        draw->AddQuad(
            ImVec2(diamondCenter.x, diamondCenter.y - diamondSize - i),
            ImVec2(diamondCenter.x + diamondSize + i, diamondCenter.y),
            ImVec2(diamondCenter.x, diamondCenter.y + diamondSize + i),
            ImVec2(diamondCenter.x - diamondSize - i, diamondCenter.y),
            IM_COL32(255, 255, 255, 255)
        );
    }

    // Hình thoi đen
    draw->AddQuadFilled(
        ImVec2(diamondCenter.x, diamondCenter.y - diamondSize),
        ImVec2(diamondCenter.x + diamondSize, diamondCenter.y),
        ImVec2(diamondCenter.x, diamondCenter.y + diamondSize),
        ImVec2(diamondCenter.x - diamondSize, diamondCenter.y),
        IM_COL32(0, 0, 0, 255)
    );
    
    // Level
    draw->AddText(ImVec2(diamondCenter.x - levelSize.x / 2, diamondCenter.y - levelSize.y / 2), IM_COL32(255, 255, 255, 255), to_string(GetLever).c_str());

    // Tên
    draw->AddText(ImVec2(namePos.x + (backgroundWidth - nameSize.x) / 2, namePos.y-2), IM_COL32(255, 255, 0, 255), heroname.c_str());
}




void Draw2dBox(ImDrawList *draw,Vector3 Transform, Camera * camera ,float height,float width ,Texture &tex,ImVec2 rootPos_Vec2)
{
    
    const int point = 4;
    const Vector3 positions[point] = {
        Transform + Vector3(width, 0, height),
        Transform + Vector3(-width, 0, height),
        Transform + Vector3(-width, 0, -height),
        Transform + Vector3(width, 0, -height),
    };
    ImVec2 vector[point];
    for (int i = 0; i < point; i++) {
        Vector3 pos = camera->WorldToViewportPoint(positions[i]);
        vector[i].x = pos.x*kWidth;
        vector[i].y = kHeight - pos.y*kHeight;
    }
    int lines[4][2] = {
        {0, 1}, {1, 2},
        {0, 3}, {2, 3},
    };
    if(boolSW[12]){
        for (const auto& line : lines) {
            draw->AddLine(ImVec2(vector[line[0]].x, vector[line[0]].y), ImVec2(vector[line[1]].x, vector[line[1]].y), ImGui::GetColorU32(selectedImGuiColor[0]), 0.5f);
        }
    }
    if(boolSW[10]){
        float scale = 42/kScale;
        if(kScale == 2 && kWidth < 500){scale = 42/(kScale+1.5);}
        float iconscale = 3*scale/2;

        ImVec2 imageSize = ImVec2(iconscale, iconscale); // Kích thước mong muốn

        ImVec2 iconPos = ImVec2(rootPos_Vec2.x - imageSize.x / 2, rootPos_Vec2.y - 15.0f - imageSize.y / 2);

        draw->AddImage((ImTextureID)(intptr_t)tex.texture, iconPos, ImVec2(iconPos.x + imageSize.x, iconPos.y + imageSize.y));
    }
}
void DrawTexture(ImDrawList *draw,Vector3 position, Camera * camera, Texture &tex, float scale,float fov) {

    Vector3 screenPos = camera->WorldToViewportPoint(position);
    if(position.z)
    {
        float scale1 = ((1/fov)+2)/4;
        float width = tex.width * scale*scale1;
        float height = tex.height * scale*scale1;

        ImVec2 topLeft = ImVec2(screenPos.x * kWidth - width / 2, kHeight - (screenPos.y * kHeight) - height / 2-25);
        ImVec2 bottomRight = ImVec2(screenPos.x * kWidth + width / 2, kHeight - (screenPos.y * kHeight) + height / 2-25);
        
    }
}
void DrawTextureFixed(ImDrawList *draw,ImVec2 point, Texture &tex, float scale) {
    float width = scale;
    float height = scale;
    ImVec2 topLeft = ImVec2(point.x - width / 2, point.y - height / 2);
    draw->AddImage((ImTextureID)(intptr_t)tex.texture, topLeft, ImVec2(topLeft.x + width, topLeft.y + height), ImVec2(0, 0), ImVec2(1, 1));
}
ImVec2 GetPlayerPosition(Vector3 Pos){
    Vector3 PosSC = Camera::get_main()->WorldToViewportPoint(Pos);
    ImVec2 Pos_Vec2 = ImVec2(kWidth - PosSC.x*kWidth, PosSC.y*kHeight);
    if (PosSC.z > 0) {
        Pos_Vec2 = ImVec2(PosSC.x*kWidth, kHeight - PosSC.y*kHeight);
    }
    return Pos_Vec2;
}
ImVec4 convertUIColorToImGuiColor(UIColor *color) {
    CGFloat red, green, blue, alpha;
    [color getRed:&red green:&green blue:&blue alpha:&alpha];
    return ImVec4((float)red, (float)green, (float)blue, (float)alpha);
}
Vector3 Lerp(Vector3 &a,const Vector3 &b, float t) {
    if(Vector3::Distance(a,b) > 1) a = b;
    return Vector3{
        a.x + (b.x - a.x) * t,
        a.y + (b.y - a.y) * t,
        a.z + (b.z - a.z) * t
    };
}
void DrawPlayerAlert(ImDrawList *draw,ImVec2 rootPos_Vec2, int index, int EnemyHp, int EnemyHpTotal, string strDistance) {
    ImVec2 hintDotRenderPos = pushToScreenBorder(ImVec2(rootPos_Vec2.x, rootPos_Vec2.y), ImVec2(kWidth, kHeight), -50);
    ImVec2 hintTextRenderPos = pushToScreenBorder(ImVec2(rootPos_Vec2.x, rootPos_Vec2.y), ImVec2(kWidth, kHeight), -50);
    draw->AddCircleFilled(hintDotRenderPos, ((float)1.7*kHeight / 39.0f), IM_COL32(0, 0, 0, 110));
    DrawCircleHealth(hintDotRenderPos, EnemyHp, EnemyHpTotal, ((float)1.7*kHeight / 39.0f),3.0f);
    auto textSize = ImGui::CalcTextSize(strDistance.c_str(), 0, ((float)kHeight / 39.0f));
    ImVec2 textPos = {
        hintDotRenderPos.x - (textSize.x)/2,
        hintDotRenderPos.y - (textSize.y)/2
    };
    if (index != -1) {
        DrawTextureFixed(draw,hintDotRenderPos,textures[index],((float)2.6*kHeight / 39.0f));
    }
    draw->AddText(NULL,((float)kHeight / 39.0f), textPos, IM_COL32(255, 255, 255, 255), strDistance.c_str());
}
void DrawDiamond(ImDrawList* drawList, ImVec2 IconBTPos, float radius, int cooldown) {
    float cx = IconBTPos.x;
    float cy = IconBTPos.y - radius/2;
    ImVec2 top(cx, cy - 1.0f);      
    ImVec2 right(cx + 1.0f, cy);    
    ImVec2 bottom(cx, cy + 1.0f);       
    ImVec2 left(cx - 1.0f, cy);         
    
    if (cooldown > 0) {
        drawList->AddTriangleFilled(top, right, bottom, IM_COL32(128, 128, 128, 255));
        drawList->AddTriangleFilled(top, bottom, left, IM_COL32(128, 128, 128, 255));
    } else {
        drawList->AddTriangleFilled(top, right, bottom, IM_COL32(0, 255, 0, 255));
        drawList->AddTriangleFilled(top, bottom, left, IM_COL32(0, 255, 0, 255));
    }
}

void DrawIconBT(ImDrawList *draw, int index, int* cooldowns, int Heroindex, int EnemyHp, int EnemyHpTotal) 
{
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    float scale = 42 / kScale;
    if (kScale == 2 && kWidth < 500) 
    {
        scale = 42 / (kScale + 1);
    }
    float iconscale = 3 * scale / 4; // Giảm xuống một nửa (điều chỉnh ở đây)

    ImVec2 IconheroPos = ImVec2(MinimapCenterX + MinimapSize.x / 2 + MinimapSize.x / 10 + (Heroindex + 5) * iconscale + round(MinimapSize.x / 20) * Heroindex, iconscale / 4 + 10); // Điều chỉnh vị trí y
    if (index != -1) {
        float borderThickness = 0.5f; // Giảm độ dày của viền xuống một nửa
        ImU32 borderColor = IM_COL32(139, 0, 0, 255); // Màu đỏ
        draw->AddCircleFilled(IconheroPos, iconscale / 4 + borderThickness, borderColor, 120); 
        DrawTextureFixed(draw, IconheroPos, textures[index], iconscale - 2 * borderThickness);
    }

    ImVec2 IconCenterPos = ImVec2(IconheroPos.x, (IconheroPos.y - iconscale / 4) - 1.0f); // Điều chỉnh vị trí y thêm để căn chỉnh
    if (cooldowns != NULL) {
        float radius = iconscale / 16; // Giảm radius xuống một nửa
        float size = 1.0f;
        ImU32 greenColor = IM_COL32(0, 200, 0, 255);
        ImU32 borderColor = IM_COL32(175, 238, 238, 255);
        float diamondSize = radius * 1.5f;
        float borderThickness = 0.75f; // Giảm độ dày của viền xuống một nửa
        if (cooldowns[2] > 0) {
            float cooldown_ratio = static_cast<float>(cooldowns[2]);

            for (float i = 0; i < borderThickness; i++) {
                draw->AddQuad(
                    ImVec2(IconCenterPos.x, IconCenterPos.y - diamondSize - i),
                    ImVec2(IconCenterPos.x + diamondSize + i, IconCenterPos.y),
                    ImVec2(IconCenterPos.x, IconCenterPos.y + diamondSize + i),
                    ImVec2(IconCenterPos.x - diamondSize - i, IconCenterPos.y),
                    borderColor
                );
            }
            draw->AddQuadFilled(
                ImVec2(IconCenterPos.x, IconCenterPos.y - diamondSize),
                ImVec2(IconCenterPos.x + diamondSize, IconCenterPos.y),
                ImVec2(IconCenterPos.x, IconCenterPos.y + diamondSize),
                ImVec2(IconCenterPos.x - diamondSize, IconCenterPos.y),
                IM_COL32(30, 30, 30, 255) 
            );

            string skill_cd = to_string(static_cast<int>(cooldowns[2]));
            auto textSize = ImGui::CalcTextSize(skill_cd.c_str());
            if (cooldowns[2] <= 9) {
                draw->AddText(ImVec2(IconCenterPos.x - textSize.x / 2 + 0.8f, IconCenterPos.y - textSize.y / 2), greenColor, skill_cd.c_str());
            }

        } else {
            for (float i = 0; i < borderThickness; i++) {
                draw->AddQuad(
                    ImVec2(IconCenterPos.x, IconCenterPos.y - diamondSize - i),
                    ImVec2(IconCenterPos.x + diamondSize + i, IconCenterPos.y),
                    ImVec2(IconCenterPos.x, IconCenterPos.y + diamondSize + i),
                    ImVec2(IconCenterPos.x - diamondSize - i, IconCenterPos.y),
                    borderColor
                );
            }
            draw->AddQuadFilled(
                ImVec2(IconCenterPos.x, IconCenterPos.y - diamondSize),
                ImVec2(IconCenterPos.x + diamondSize, IconCenterPos.y),
                ImVec2(IconCenterPos.x, IconCenterPos.y + diamondSize),
                ImVec2(IconCenterPos.x - diamondSize, IconCenterPos.y),
                greenColor
            );
        }
    }
// Vẽ thanh máu
float healthBarWidth = iconscale;
float healthBarHeight = 2.75f;
ImVec2 healthBarPos = ImVec2(IconheroPos.x - healthBarWidth / 2, IconheroPos.y + iconscale / 2 + healthBarHeight); // Điều chỉnh vị trí thanh máu

// Vẽ nền thanh máu
draw->AddRectFilled(healthBarPos, ImVec2(healthBarPos.x + healthBarWidth, healthBarPos.y + healthBarHeight), IM_COL32(0, 0, 0, 150));

// Vẽ thanh máu
if (EnemyHpTotal > 0) {
    float healthRatio = (float)EnemyHp / EnemyHpTotal;
    ImU32 healthColor = IM_COL32(102, 207, 252, 255);
    draw->AddRectFilled(healthBarPos, ImVec2(healthBarPos.x + healthBarWidth * healthRatio, healthBarPos.y + healthBarHeight), healthColor);
}

// Vẽ icon bổ trợ
ImVec2 IconBTPos = ImVec2(IconheroPos.x, IconheroPos.y + iconscale + healthBarHeight + 1.0f); // Sửa khoảng cách thành 1.0f
if (cooldowns != NULL) {
    if (cooldowns[4] > 0) {
        int indexbt;
        int index2 = cooldowns[4] - 80100;
        switch (index2) {
            case 2:
                indexbt = findHeroByName("capcuu").index;
                break;
            case 3:
                indexbt = findHeroByName("ngatngu").index;
                break;
            case 4:
                indexbt = findHeroByName("trungtri").index;
                break;
            case 5:
                indexbt = findHeroByName("suynhuoc").index;
                break;
            case 7:
                indexbt = findHeroByName("thanhtay").index;
                break;
            case 8:
                indexbt = findHeroByName("bocpha").index;
                break;
            case 9:
                indexbt = findHeroByName("tochanh").index;
                break;
            case 10:
                indexbt = findHeroByName("gamthet").index;
                break;
            case 15:
                indexbt = findHeroByName("tocbien").index;
                break;
            case 16:
                indexbt = findHeroByName("trungtri").index;
                break;
            default:
                indexbt = -1;
                break;
        }
        if (indexbt != -1) {
            DrawTextureFixed(draw, IconBTPos, textures[indexbt], scale / 2); // Giảm kích thước icon bổ trợ xuống còn 1/2
        }
        if (cooldowns[3] > 0) {
            draw->AddCircleFilled(IconBTPos, scale / 2, IM_COL32(0, 0, 0, 128));
            string cooldownText = to_string(cooldowns[3]);
            ImVec2 textSize = ImGui::CalcTextSize(cooldownText.c_str());
            ImVec2 textPos = ImVec2(IconBTPos.x - textSize.x / 2, IconBTPos.y - textSize.y / 2);
            draw->AddText(textPos, IM_COL32(255, 255, 255, 255), cooldownText.c_str());
        }
    }
  }
}

void DrawSkillCD(ImDrawList *draw,ImVec2 rootPos_Vec2,void* Enemy)
{
    float boxHeight = kHeight / 10;
    float boxWidth = boxHeight * 0.375f;
    ImVec2 vStart = {rootPos_Vec2.x - boxWidth - 6, rootPos_Vec2.y - boxHeight};
    ImVec2 vEnd = {vStart.x + 2*boxWidth, vStart.y + boxHeight};
    void* SkillControl = *(void**)((uint64_t)Enemy + ESP[57]);
    if(SkillControl != NULL)
    {
        int* cooldowns = SkillControlAll1(SkillControl);
        if(cooldowns != NULL)
        {
            float size = boxHeight / 8;
            ImVec2 position = ImVec2(vStart.x - size - boxWidth  + 20.0f, vStart.y + (size / 2));

            ImVec2 position2 = ImVec2(vStart.x - size - boxWidth  + 20.0f, position.y + size * 2);

            ImVec2 position3 = ImVec2(vStart.x - size - boxWidth  + 20.0f, position2.y + size * 2);

            ImVec2 position4 = ImVec2(vStart.x - size - boxWidth  + 20.0f, vEnd.y - size / 2);

            ImU32 color = ImColor(1.0f, 0.5f, 0.0f, 1.0f);
            int cd1 = cooldowns[0];
            int cd2 = cooldowns[1];
            int cd3 = cooldowns[2];
            int cd4 = cooldowns[3];
            DrawCd(draw,position,size,color, cd1);
            DrawCd(draw,position2,size,color, cd2);
            DrawCd(draw,position3,size,color, cd3);
            DrawCd(draw,position4,size,color, cd4);
        }
        free(cooldowns);
    }
    
}
void DrawIconMap(ImDrawList *draw,Vector3 EnemyPos,int index, int EnemyHp, int EnemyHpTotal)
{
    float scaleicon = Slider[3].value/kScale;
    if(kScale == 2 && kWidth < 500){scaleicon = Slider[3].value/(kScale+1);}
    int scalemapX = 109;
    int scalemapY = scalemapX;
    if(roomtype == 5){
        if(MapType == 1)
        {
            scalemapX = 82.5;
            scalemapY = 78.8;
        }
        else if(MapType == 2)
        {
            scalemapX = 84;
            scalemapY = 87.5;
        }
    }
    if(is3V3Minimap){
        if(MapType == 1)
        {
            scalemapX = 135;
            scalemapY = scalemapX/3;
        }
        else if(MapType == 2)
        {
            scalemapX = 130;
            scalemapY = scalemapX/3;
        }

    }
    if(MapType == 1)
    {
        ImVec2 enemyiconPos = {
        MinimapCenterX + EnemyPos.x*MinimapSize.x/scalemapX,
        MinimapCenterY - EnemyPos.z*MinimapSize.y/scalemapY
        };
        if(isFliped){
            enemyiconPos.x = MinimapCenterX - EnemyPos.x*MinimapSize.x/scalemapX;
            enemyiconPos.y = MinimapCenterY + EnemyPos.z*MinimapSize.y/scalemapY;
        }
        if(is3V3Minimap && isFliped){
            enemyiconPos.x = MinimapCenterX - EnemyPos.x*MinimapSize.x/scalemapX;
            enemyiconPos.y = MinimapCenterY - EnemyPos.z*MinimapSize.y/scalemapY;
        }
        if (index != -1) {
            DrawCircleHealthMiniMap(ImGui::GetForegroundDrawList(), enemyiconPos, EnemyHp, EnemyHpTotal, scaleicon/2,1.0f); // Thay đổi ở đây
            DrawTextureFixed(ImGui::GetForegroundDrawList(),enemyiconPos,textures[index],scaleicon);
        }   
    }
    else if(MapType == 2)
    {
        ImVec2 enemyiconPos = {
        BigmapCenterX + EnemyPos.x*BigmapSize.x/scalemapX,
        BigmapCenterY - EnemyPos.z*BigmapSize.y/scalemapY
        };
        if(isFliped){
            enemyiconPos.x = BigmapCenterX - EnemyPos.x*BigmapSize.x/scalemapX;
            enemyiconPos.y = BigmapCenterY + EnemyPos.z*BigmapSize.y/scalemapY;
        }
        if(is3V3Minimap && isFliped){
            enemyiconPos.x = BigmapCenterX - EnemyPos.x*BigmapSize.x/scalemapX;
            enemyiconPos.y = BigmapCenterY - EnemyPos.z*BigmapSize.y/scalemapY;
        }
        if (index != -1) {
            DrawCircleHealthMiniMap(ImGui::GetForegroundDrawList(), enemyiconPos, EnemyHp, EnemyHpTotal,scaleicon,1.0f); // Thay đổi ở đây
            DrawTextureFixed(ImGui::GetForegroundDrawList(),enemyiconPos,textures[index],2*scaleicon);
        }   
    }
}
Vector3 VectorUnitFromGoc(Vector3 goc,Vector3 diem){
    Vector3 vector = diem - goc;
    float magnitude = sqrt(vector.x * vector.x + vector.y * vector.y + vector.z * vector.z);
    return vector / magnitude;
}
Vector3 VectorUnit(Vector3 location){
    float magnitude = sqrt(location.x * location.x + location.y * location.y + location.z * location.z);
    return location / magnitude;
}
float ClosestDistanceEnemy(Vector3 myPos, Vector3 enemyPos, Vector3 direction) {
    Vector3 AC = enemyPos - myPos;
    Vector3 AB = direction*-1;
    float t = Vector3::Dot(AC, AB);
    Vector3 projectionPoint = myPos + AB * t;
    return Vector3::Distance(projectionPoint, enemyPos);
}
void ChooseEnemy(ImVec2 &aimPos, Vector3 &AimVector,int giatri,int Distance,int EnemyHp,int EnemyHpTotal,float myEpPercent,Vector3 myPos,Vector3 EnemyPos,ImVec2 rootPos_Vec2,int &lowestHp,float &lowestHpPercent,float &closestEnemyDistance,float &closestEnemyDistanceView, Vector3 AimVector1)
{
    
    switch (giatri) {
        case 0:
                if(EnemyHp < lowestHp && EnemyHp > 0 ){
                lowestHp = EnemyHp;
                AimVector = AimVector1;
                aimPos = rootPos_Vec2;
            }
            break;
        case 1:
            if(myEpPercent < lowestHpPercent && EnemyHp > 0 ){
                lowestHpPercent = myEpPercent;
                AimVector = AimVector1;
                aimPos = rootPos_Vec2;
            }
            break;
        case 2:
            if(Distance < closestEnemyDistance && EnemyHp > 0){
                closestEnemyDistance = Distance;
                AimVector = AimVector1;
                aimPos = rootPos_Vec2;
            }
            break;
        case 3:
            float distance = ClosestDistanceEnemy(myPos, EnemyPos, CurrentPosition);
            if(distance < closestEnemyDistanceView && EnemyHp > 0){
                closestEnemyDistanceView = distance;
                AimVector = AimVector1;
                aimPos = rootPos_Vec2;
            }
            break;
    }
}
Vector3 calculateSkillDirection(Vector3 myPosi, Vector3 enemyPosi, Vector3 moveForward, int currentSpeed, float bullettime, float Ranger) {
    Vector3 futureEnemyPos = Vector3::zero();

    Vector3 toEnemy = enemyPosi - myPosi;
    float distanceToEnemy = Vector3::Magnitude(toEnemy);

    float defaultBulletSpeed = Ranger/bullettime;

    float timeToHit = distanceToEnemy/defaultBulletSpeed;

    futureEnemyPos = enemyPosi + moveForward * currentSpeed * timeToHit;
    Vector3 shootingDirection = futureEnemyPos - myPosi;
    return Vector3::Normalized(shootingDirection);
}
Vector3 CalculateShootingDirection(Vector3 &futureEnemyPos,Vector3 myPos, Vector3 enemyPos, Vector3 enemyDirection, float enemySpeed, float bulletSpeed) {
    Vector3 toEnemy = enemyPos - myPos;
    float distanceToEnemy = Vector3::Magnitude(toEnemy);
    float timeToHit = distanceToEnemy / bulletSpeed;
    futureEnemyPos = enemyPos + enemyDirection * enemySpeed * timeToHit;
    Vector3 shootingDirection = futureEnemyPos - myPos;
    return Vector3::Normalized(shootingDirection);
}

void (*SendMoveDirection)(void *instance, Vector2 a, Vector2 b);
void _SendMoveDirection(void *instance, Vector2 a, Vector2 b)
{
    if(instance != NULL)
    {
        MoveInstance = instance;
    }
    return SendMoveDirection(instance,a,b);
}
void moveE(void *HoaTarget,Vector3 MP,Vector3 EP)
{
    Vector3 HP = ActorLinker_getPosition(HoaTarget); 
    Vector3 direction =  HP - MP;
    Vector2 MyDir = {0, 0};
    Vector2 direction2D = {direction.x, direction.z};
    direction2D = Vector2::Normalized(direction2D);
    if(isFliped) direction2D = {-direction.x,- direction.z};
    int speed = 400;
    Vector2 moveDirection = {direction2D.x * speed, direction2D.y * speed};
    SendMoveDirection(MoveInstance,MyDir,moveDirection);
}
void FloMua(ImDrawList *draw,void* ForE)
{
    int stt = 0;
    if(MoveInstance != NULL && boolUS[19] && !(Flo_Enemy->enemies->empty()))
    {
        giatriBool[12] = true;
        void* HoaTarget = nullptr;
        float minDistance = numeric_limits<float>::infinity();
        if(ForE != NULL && espManager->MyPlayer != NULL)
        {
            Vector3 MP = ActorLinker_getPosition(espManager->MyPlayer); // Vị trí nhân vật chính
            Vector3 EP = ActorLinker_getPosition(ForE); // Vị trí địch
            int floc1 = -1;
            int floc2 = 0;
            int floc3 = -1;
            int* cooldowns = SkillControlAll(espManager->MyPlayer);
            if( cooldowns != NULL) 
            {
                floc1 = cooldowns[0];
                floc2 = cooldowns[1];
                floc3 = cooldowns[2];
            }
            if(boolSW[15])
            {
                float Dis = Vector3::Distance(MP, EP);
                if ( Dis > 2.4f && Dis < 5.0f && Req1 != NULL)
                {
                    if(floc1==0)
                    {
                        Reqskill2(Req1,false);
                        Reqskill(Req1);
                    }
                } 
            }
            if(boolSW[16])
            {
                float Dis = Vector3::Distance(MP, EP);
                if ( Dis > 2.4f && Dis < 5.0f && Req3 != NULL && Flo_Enemy->enemies->size())
                {
                    if(floc3==0)
                    {
                        Reqskill2(Req3,false);
                        Reqskill(Req3);
                    }
                } 
            }
            Vector3 HP = Vector3::zero();
            for (int i = 0; i < Flo_Enemy->enemies->size(); i++) 
            {
                void *Hoa = (*Flo_Enemy->enemies)[i]->object;
                if(Hoa != NULL && espManager->MyPlayer != NULL)
                {
                    HP = ActorLinker_getPosition(Hoa); // Vị trí bông hoa
                    if(!isInstanceRemoved(HP))
                    {
                        
                        float Dis2 = Vector3::Distance(MP, HP);
                        if (Dis2 < 1.8f){
                            addRemovedInstance(HP);
                            continue;
                        }
                        else if(Dis2 < minDistance)
                        {
                            stt++;
                            if(boolUS[20])
                            {                            
                            ImVec2 FloPOS = GetPlayerPosition(MP);
                            ImVec2 HoaPOS = GetPlayerPosition(HP);
                            draw->AddCircleFilled(ImVec2(HoaPOS.x, HoaPOS.y), 2.0f, ImColor(255, 255, 0)); 
                            // Vẽ vòng tròn màu vàng                            
                             draw->AddLine(ImVec2(FloPOS.x, FloPOS.y), ImVec2(HoaPOS.x, HoaPOS.y), ImColor(0, 255, 255), 0.1f); 
                             // Vẽ đường kẻ màu xanh AQua
                            }
                            HoaTarget = Hoa;
                        }
                    }
                }
                
            }
            if(ForE != NULL && espManager->MyPlayer != NULL)
            {
                float Dis = Vector3::Distance(MP, EP);
                if ( Dis < 1.5f) 
                { 
                    if (Req2!= NULL ) 
                    {
                        if(HoaTarget != NULL)
                        {
                            moveE(HoaTarget,MP,EP);
                        }
                        if(floc2==0)
                        {
                            Reqskill2(Req2,false);
                            Reqskill(Req2);
                        }
                        
                    }
                    
                }
                else if (Dis < 7.0f) 
                { 
                    if (Req0 != NULL&& floc2==0) 
                    { 
                        Reqskill2(Req0,false);
                        Reqskill(Req0);
                        
                    }
                }
                
            }
        }
    }
    else if(stt == 0)
    {
        if(giatriBool[12] && MoveInstance)
        {
            StopInput(MoveInstance);
            giatriBool[12] = false;
        }
    }
}
void DrawOverlay(ImDrawList *draw) {
    if ((!boolUS[11] && !boolUS[9] && !boolUS[14] && !boolUS[19])|| espManager->enemies->empty()) {
        previousEnemyPositions.clear();
        return;
    }
    void *actorLinker = espManager->MyPlayer;
    if (!actorLinker) return;
    Vector3 myPos = ActorLinker_getPosition((void *)actorLinker);
    CGContextRef context = UIGraphicsGetCurrentContext();
    //ImVec2 myPos_Vec2 = GetPlayerPosition(myPos);
    int lowestHp = 1000000000;
    int lowestHp2 = 1000000000;
    float lowestHpPercent = 1000000000;
    float closestEnemyDistance = 1000000000;
    float closestEnemyDistanceView = 1000000000;
    float closestFlo = 1000000000;
    ImVec2 aimPos = ImVec2(0,0);
    ImVec2 aimPos2 = ImVec2(0,0);
    int soluonghero = 0;
    void* Entity = NULL;
    void* EnemyFlo = NULL;
    for (int i = 0; i < espManager->enemies->size(); i++) {
        void *Enemy = (*espManager->enemies)[i]->object;
        if (!Enemy) continue;
        void *LObjWrapper = *(void**)((uint64_t)Enemy + ESP[28]);
        if (!LObjWrapper_get_IsDeadState(LObjWrapper)) {
            void *ValuePropertyComponent = *(void**)((uint64_t)Enemy + ESP[27]);
                void *EnemyLinker = (*ActorLinker_enemy->enemies)[i]->object;
                void *PlayerMovement = LActorRoot_get_PlayerMovement(Enemy);
                int speed = get_speed(PlayerMovement);
            if (Camera::get_main() != nullptr) 
            {
                Vector3 EnemyPos = Vector3::zero();
                VInt3 NowLocation = LActorRoot_get_location(Enemy);
                VInt3 forwardEnemy = LActorRoot_get_forward(Enemy);

                float speedEnemy = (float)speed/1000.0f;
                bool isVisible = ActorLinker_get_bVisible(EnemyLinker);
                if(isVisible){
                    EnemyPos = ActorLinker_getPosition((void *)EnemyLinker);
                    previousEnemyPositions[(uintptr_t)Enemy] = EnemyPos;
                }
                else
                {
                    EnemyPos = VInt2Vector(NowLocation, forwardEnemy);
                    if (previousEnemyPositions.find((uintptr_t)Enemy) == previousEnemyPositions.end()) {
                        previousEnemyPositions[(uintptr_t)Enemy] = EnemyPos;
                    }
                    EnemyPos = Lerp(previousEnemyPositions[(uintptr_t)Enemy], EnemyPos, 0.2f);
                    previousEnemyPositions[(uintptr_t)Enemy] = EnemyPos;
                }
                ImVec2 rootPos_Vec2 = GetPlayerPosition(EnemyPos);
                float Distance = Vector3::Distance(myPos, EnemyPos);
                int EnemyHp = ValuePropertyComponent_get_actorHp(ValuePropertyComponent);
                int EnemyHpTotal = ValuePropertyComponent_get_actorHpTotal(ValuePropertyComponent);
                float EpPercent = (float)EnemyHp/EnemyHpTotal;
                int EnemyEp = ValuePropertyComponent_get_actorEp(ValuePropertyComponent);
                int EnemyEpTotal = ValuePropertyComponent_get_actorEpTotal(ValuePropertyComponent);
                int GetLever = ValuePropertyComponent_get_actorSoulLevel(ValuePropertyComponent);
                float distancess = ClosestDistanceEnemy(myPos, EnemyPos, CurrentPosition);

                int* cooldowns = SkillControlAll(actorLinker);
                if (cooldowns != NULL) {
                    skillid = cooldowns[4]; // Hoặc cooldowns[4] tuỳ thuộc vào logic của bạn, bạn có thể dựa vào hàm SkillControlAll để xác định
                
                    if(boolUS[14] && EpPercent <= Slider[1].value/100.0f && Distance < 5.1f && EpPercent > 0 && skillid == 80108)
                    {
                        if(CanRequestSkill(BPinstance,5))
                            RequestUseSkillSlot(BPinstance,5,0,0,0);
                    }
                    if(boolUS[24] &&  (skillid == 80104 || skillid == 80116) && cooldowns[3] == 0)
                    {
                        void* *actorManager = get_actorManager();
                        if (actorManager == nullptr) return;
                        monoList<void**> *GetAllMonster = GetAllMonsters(actorManager);
                        if (GetAllMonster == nullptr) return;

                        void* **actorLinkersm = (void* **) GetAllMonster->getItems();
                        void *ValueLinkerComponent1 = *(void**)((uint64_t)actorLinker + ESP[11]);
                        for (int i = 0; i < GetAllMonster->getSize(); i++)
                        {
                            void* actorLinkerMonster = actorLinkersm[(i *2) + 1];
                            if (actorLinkerMonster == nullptr) continue;
                            void* ObjLinker = *(void**)((uintptr_t)actorLinkerMonster + ESP[41]);
                            void *ValueLinkerComponent = *(void**)((uint64_t)actorLinkerMonster + ESP[11]);
                            int health = ValueLinkerComponent_get_actorEp(ValueLinkerComponent);
                            if(health < 1) continue;
                            int ConfigID = *(int*)((uintptr_t)ObjLinker + ESP[85]);
                            if(ConfigID == 7010 || ConfigID == 7011 || ConfigID == 7012 || ConfigID == 70093 || ConfigID == 70092 || ConfigID == 7024 || ConfigID == 7009)
                            {
                                Vector3 EnemyPos = ActorLinker_getPosition(actorLinkerMonster);
                                float distance = Vector3::Distance(myPos,EnemyPos);
                                if(distance > 5.0f) continue;
                                int level =  ValueLinkerComponent_get_actorSoulLevel(ValueLinkerComponent1) -1 ;
                                if(health <= (1350 + 100*level))
                                {
                                    // 7010: bùa xanh
                                    // 7011: bùa đỏ
                                    // 7012: rồng
                                    // 70093: caesar
                                    // 70092: bạo chúa
                                    // 7024: rồng ánh sáng
                                    //7009: caesar hắc ám
                                    Reqskill2(Req5,false);
                                    Reqskill(Req5);
                                }
                            }
                        }
                    }
                }
                

                
            
                bool isInRange = false;
                float boxHeight = kHeight / 10;
                if(boolUS[19])
                {
                    EnemyTarget.myPos = myPos;
                    void* ObjLinker = *(void**)((uintptr_t)actorLinker + ESP[41]);
                    if (!ObjLinker) return; // dừng
                    EnemyTarget.ConfigID = *(int*)((uintptr_t)ObjLinker + ESP[85]);
                    if (!EnemyTarget.ConfigID) return; // dừng
                    if (EnemyTarget.ConfigID == 521){
                       if(Distance <= Rangeskill1 && Distance < closestFlo)
                       {
                            EnemyFlo = EnemyLinker;
                       }
                    }
                }
                if(boolUS[9])
                { // Aim đón
                    EnemyTarget.myPos = myPos;
                    void* ObjLinker = *(void**)((uintptr_t)actorLinker + ESP[41]);
                    if (!ObjLinker) return; // dừng
                    EnemyTarget.ConfigID = *(int*)((uintptr_t)ObjLinker + ESP[85]); 
                    if (!EnemyTarget.ConfigID) return; // dừng
                    
                    if (EnemyTarget.ConfigID == 196){
                        EnemyTarget.Ranger = Rangeskill2;
                        EnemyTarget.bullettime = 0.43f;
                        tagid = 2;
                    }
                    if (EnemyTarget.ConfigID == 157){
                        EnemyTarget.Ranger = Rangeskill2;
                        EnemyTarget.bullettime = 0.8f;
                        tagid = 2;
                    }
                    if (EnemyTarget.ConfigID == 175){
                        EnemyTarget.Ranger = Rangeskill2;
                        EnemyTarget.bullettime = 0.7f;
                        tagid = 2;
                    }
                    if (EnemyTarget.ConfigID == 108){
                        EnemyTarget.Ranger = Rangeskill2;
                        EnemyTarget.bullettime = 0.85f;
                        tagid = 2;
                    }
                    if (EnemyTarget.ConfigID == 174){
                        EnemyTarget.Ranger = Rangeskill1;
                        EnemyTarget.bullettime = 0.99f;
                        tagid = 1;
                    }
                    if (EnemyTarget.ConfigID == 521){
                        EnemyTarget.Ranger = Rangeskill1;
                        EnemyTarget.bullettime = 0.5f;
                        tagid = 1;
                    }
                    if (EnemyTarget.ConfigID == 195){
                        EnemyTarget.Ranger = Rangeskill2;
                        EnemyTarget.bullettime = 0.3f;
                        tagid = 2;
                    }
                    if (EnemyTarget.ConfigID == 529){
                        EnemyTarget.Ranger = Rangeskill2;
                        EnemyTarget.bullettime = 0.85f;
                        tagid = 2;
                    }
                    if (EnemyTarget.ConfigID == 545){
                        EnemyTarget.Ranger = Rangeskill2;
                        EnemyTarget.bullettime = 0.7f;
                        tagid = 2;
                    }
                    if (EnemyTarget.ConfigID == 152){
                        EnemyTarget.Ranger = Rangeskill2;
                        EnemyTarget.bullettime = 1.1f;
                        tagid = 2;
                    }
                    if (Distance <= EnemyTarget.Ranger && skillSlot == tagid)
                    {
                        if (aimMode == 0 && EnemyHp < lowestHp)
                        {
                            Entity = Enemy;
                            EnemyTarget.enemyPos = VIntVector(NowLocation);
                            EnemyTarget.moveForward = VIntVector(forwardEnemy);
                            EnemyTarget.currentSpeed = speedEnemy;
                            lowestHp = EnemyHp;
                        }
                        if (aimMode == 1)
                        {
                            if (EpPercent < lowestHpPercent)
                            {
                                Entity = Enemy;
                                EnemyTarget.enemyPos = VIntVector(NowLocation);
                                EnemyTarget.moveForward = VIntVector(forwardEnemy);
                                EnemyTarget.currentSpeed = speedEnemy;
                                lowestHpPercent = EpPercent;
                            }
                        
                            if (EpPercent == lowestHpPercent && EnemyHp < lowestHp2)
                            {
                                EnemyTarget.enemyPos = VIntVector(NowLocation);
                                EnemyTarget.moveForward = VIntVector(forwardEnemy);
                                EnemyTarget.currentSpeed = speedEnemy;
                                lowestHp2 = EnemyHp;
                                lowestHpPercent = EpPercent;
                            }
                        }
                        
                        if (aimMode == 2 && Distance < closestEnemyDistance)
                        {
                            Entity = Enemy;
                            EnemyTarget.enemyPos = VIntVector(NowLocation);
                            EnemyTarget.moveForward = VIntVector(forwardEnemy);
                            EnemyTarget.currentSpeed = speedEnemy;
                            closestEnemyDistance = Distance;
                        }
                    
                        if (aimMode == 3 && distancess < closestEnemyDistanceView)
                        {
                            Entity = Enemy;
                            EnemyTarget.enemyPos = VIntVector(NowLocation);
                            EnemyTarget.moveForward = VIntVector(forwardEnemy);
                            EnemyTarget.currentSpeed = speedEnemy;
                            closestEnemyDistanceView = distancess;
                        }
                    }

                }
                if(boolUS[11])
                {
                    string heroname;
                    void* ObjLinker = *(void**)((uintptr_t)EnemyLinker + ESP[41]);
                    if (!ObjLinker) return;
                    int sheroID = *(int*)((uintptr_t)ObjLinker + ESP[85]);
                    if (!sheroID) return;
                    HeroData heroData = findHeroById(sheroID);
                    heroname = string(heroData.name);
                    bool outscreen = isOutsideScreen(ImVec2(rootPos_Vec2.x, rootPos_Vec2.y), ImVec2(kWidth, kHeight));
                    ostringstream oss;
                    oss << fixed << setprecision(1) << Distance << "m";
                    string strDistance = oss.str();
                    if(boolSW[9]) // hiển thị icon minimap
                    {
                        void* SkillControl = *(void**)((uint64_t)Enemy + ESP[57]);
                        if(SkillControl != NULL)
                        {
                            int* cooldowns = SkillControlAll1(SkillControl);
                            DrawIconBT(draw, heroData.index, cooldowns, i, EnemyHp, EnemyHpTotal);
                            free(cooldowns);
                        }
                    }
                    if(boolSW[8]) // Nếu địch không hiển thị trên map
                    {	
                        if(isVisible){ // nếu ĐÚNG nhìn thấy địch
                            continue; // bỏ qua không vẽ nửa
                        }
                    }
                    if(boolSW[11]) // hiển thị icon minimap
                    {
                        DrawIconMap(draw, VInt2Vector(NowLocation, forwardEnemy), heroData.index, EnemyHp, EnemyHpTotal);
                    }
                    isInRange = true;
                    soluonghero++;

                    if(!isInRange) continue;
                    if(boolSW[12])
                    {
                        boxHeight = kHeight / 8;
                    }
                    if (boolSW[0]) { // hiển thị line địch
                        draw->AddLine(ImVec2(kWidth / 2, 45), ImVec2(rootPos_Vec2.x, rootPos_Vec2.y), ImGui::GetColorU32(selectedImGuiColor[2]), 0.1f);
                        
                    }
                    if(boolSW[1] && !outscreen){ // hiển thị điểm địch
                        
                        draw->AddCircleFilled(ImVec2(rootPos_Vec2.x, rootPos_Vec2.y), 3.0f, ImColor(0, 255, 0));
                    }
                    if (boolSW[3] && !outscreen) { // hiển thị khoảng cách địch
                        auto textSize = ImGui::CalcTextSize(strDistance.c_str(), 0, ((float)kHeight / 39.0f));
                        draw->AddText(NULL, ((float)kHeight / 39.0f), {rootPos_Vec2.x - (textSize.x/2), rootPos_Vec2.y + 5}, IM_COL32(0, 180, 255, 255), strDistance.c_str());
                    }

                    if (boolSW[4] && outscreen) {
                        DrawPlayerAlert(draw,rootPos_Vec2, heroData.index, EnemyHp, EnemyHpTotal, strDistance);
                    }
                    
                    if(boolSW[6] && !outscreen) // hiển thị cd skill địch
                    {
                        DrawSkillCD(draw,rootPos_Vec2,Enemy);
                    }
                    if(boolSW[7] && !outscreen)
                    {
                        DrawHealthBar(draw, rootPos_Vec2, EnemyHp, EnemyHpTotal, EnemyEp, EnemyEpTotal, heroname, GetLever,EpPercent);
                        
                    }
                    
                    if((boolSW[10] || boolSW[12] || boolSW[2]) && !outscreen) // hiển thị icon địch
                    {
                        if(!boolSW[2] && heroData.heroid != -1)
                        {
                            Draw2dBox(draw, EnemyPos, Camera::get_main(), 0.6,0.6,textures[heroData.index],rootPos_Vec2);
                        }
                        else if(boolSW[2] && heroData.heroid != -1)
                        {
                            Draw3dBox(draw, EnemyPos, Camera::get_main(),textures[heroData.index]);
                        }
                    }
                   
                }
            }
        }
    }
    
    if(Entity != NULL && EnemyTarget.myPos != Vector3::zero() && EnemyTarget.enemyPos != Vector3::zero() && find(targetConfigIDs.begin(), targetConfigIDs.end(), EnemyTarget.ConfigID) != targetConfigIDs.end())
    {
        Vector3 futureEnemyPos1 = Vector3::zero();
        Vector3 toEnemy = EnemyTarget.enemyPos - EnemyTarget.myPos;
        float distanceToEnemy = Vector3::Magnitude(toEnemy);
        float defaultBulletSpeed = EnemyTarget.Ranger/EnemyTarget.bullettime;
        float timeToHit = distanceToEnemy/defaultBulletSpeed;
        futureEnemyPos1 = EnemyTarget.enemyPos + EnemyTarget.moveForward * EnemyTarget.currentSpeed* timeToHit;
        ImVec2 RootVec2 = GetPlayerPosition(futureEnemyPos1);
        draw->AddCircleFilled(RootVec2, 3.0f, ImColor(255,0, 0));
    }
    else
    {
        EnemyTarget.enemyPos = Vector3::zero();
        EnemyTarget.moveForward = Vector3::zero();
    }
    if(boolUS[11])
    {
/*
        ImVec4 colorWithAlpha = convertUIColorToImGuiColor([UIColor clearColor]);
        RenderFilledRectangleWithText(draw,ImVec2(kWidth / 2, 10),ImVec2(50,30),colorWithAlpha,to_string(soluonghero).c_str());
        */
    }
    FloMua(draw,EnemyFlo); 
}
Vector3 (*GetUseSkillDirection)(void* instance,bool isUseSkill);
Vector3 _GetUseSkillDirection(void* instance,bool isUseSkill)
{
    if(instance != NULL && skillSlot > 0 &&  skillSlot < 4 && boolUS[9] && find(targetConfigIDs.begin(), targetConfigIDs.end(), EnemyTarget.ConfigID) != targetConfigIDs.end())
    {
        if (EnemyTarget.myPos != Vector3::zero() && EnemyTarget.enemyPos != Vector3::zero() && skillSlot == tagid) {
            return calculateSkillDirection(
                EnemyTarget.myPos, 
                EnemyTarget.enemyPos, 
                EnemyTarget.moveForward, 
                EnemyTarget.currentSpeed,
                EnemyTarget.bullettime,
                EnemyTarget.Ranger
            );
        }
    }
    return GetUseSkillDirection(instance,isUseSkill);
}

void* (*Skill_lateUpdate)(void* instance,int deltaTime);
void _Skill_lateUpdate(void* instance,int deltaTime)
{
    if(instance != NULL)
    {
        int skillslot = *(int*) ((uintptr_t)instance + AimAndBT[9]);
        void* skillControl = *(void**) ((uintptr_t)instance + AimAndBT[8]);
        int range = *(int*) ((uintptr_t)skillControl + AimAndBT[5]);
        Vector3 currentPosition = *(Vector3*) ((uintptr_t)skillControl + AimAndBT[6]);
        if(skillslot == 0)
        {
            Req0 = instance;
        }
        else if(skillslot == 1)
        {
            Req1 = instance;
        }
        else if(skillslot ==2)
        {
            Req2 = instance;
        }
        
        else if(skillslot == 3)
        {
            Req3 = instance;
        }
        else if(skillslot == 5)
        {
            Req5 = instance;
        }
        else if(skillslot == 9)
        {
            Req9 = instance;
        }
        if(skillslot == 1)
        {
            Rangeskill1 = (float)range/1000.0f;
        }
        else if(skillslot ==2)
        {
            Rangeskill2 = (float)range/1000.0f;
        }
        
        else if(skillslot == 3)
        {
            Rangeskill3 = (float)range/1000.0f;
        }
        if(skillslot == skillSlot)
        {
            CurrentPosition = currentPosition;
        }

        
    }
    
    Skill_lateUpdate(instance,deltaTime);
}
void (*updatelogic)(void *instance);
int (*GetCurSkillSlotType)(void* instance);
void _updatelogic(void *instance){
	if(instance != NULL)
	{
        skillSlot = GetCurSkillSlotType(instance);
        void *actorLinker = espManager->MyPlayer;
        if (actorLinker)
        {
            if(boolUS[13])// auto băng sương
            {
                void *ValueLinkerComponent = *(void**)((uint64_t)actorLinker + ESP[11]);
                myEpPercent = (float)ValueLinkerComponent_get_actorEp(ValueLinkerComponent)/ValueLinkerComponent_get_actorEpTotal(ValueLinkerComponent);
                if(myEpPercent <= Slider[0].value/100.0f && CanRequestSkill(instance,9))
                {
                    RequestUseSkillSlot(instance,9,0,0,0);
                }
            }
            BPinstance = instance;
        }
	}
	return updatelogic(instance);
}
