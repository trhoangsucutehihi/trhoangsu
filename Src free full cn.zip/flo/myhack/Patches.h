#ifndef PATCHES_H
#define PATCHES_H
#include "Overlay.h"
THPatchMem patcher;
void (*RefreshHeroPanel)(void *instance,bool v1,bool v2,bool v3);
void addNewPatch(uint64_t offset,char* hexPattern, bool* setting) {
	uint64_t address = offset;
	patch_infos.push_back({address, hexPattern, setting, false});
}
void addNewPatch(uint64_t offset,char* hexPattern) {
	uint64_t address = offset;
    patch_infos.push_back({address, hexPattern, &activeALL, false});
}
void addNewPatchAnog(uint64_t offset,char* hexPattern,bool* setting) {
	uint64_t address = offset;
    patch_infos.push_back({address, hexPattern, setting, false});
}
//skin mod
bool (*IsHaveHeroSkin)(void *instance,int heroID,int skinID);
bool _IsHaveHeroSkin(void *instance,int heroID,int skinID){
	if(instance != NULL && boolUS[4])
	{
		return true;
	}
	return IsHaveHeroSkin(instance,heroID,skinID);
}
bool (*CanUseSkin)(void *instance,int heroID,int skinID);
bool _CanUseSkin(void *instance,int heroID,int skinID){
	if(instance != NULL && boolUS[4])
	{
		espManager->removeAllEnemyGivenObject();
		espManager->MyPlayer = NULL;
		[protocol setEnable:YES];
		protocol._heroID = heroID;
		protocol._skinID = skinID;
		return true;
	}
	return CanUseSkin(instance,heroID,skinID);
}
bool (*IsPrimeFreeSkin)(void *instance,int heroID,int skinID);
bool _IsPrimeFreeSkin(void *instance,int heroID,int skinID){
	if(instance != NULL)
	{
		skillid = skinID;
		herroid = heroID;

	}
	return IsPrimeFreeSkin(instance,heroID,skinID);
}	
void* (*unpack)(void *instance,void* srcBuf,long cutVer);
void* _unpack(void *instance,void* srcBuf,long cutVer){
	if(instance != NULL &&  boolUS[4])
	{
		void * call = unpack(instance,srcBuf,cutVer);
		uint32_t heroID = *(uint32_t *)((uint64_t)instance + ModSkin[7]);
		uint16_t skinID = *(uint16_t *)((uint64_t)instance + ModSkin[8]);
		if([protocol isEnabled])
		{
			if(heroID == protocol._heroID && protocol._heroID > 0)
			{
				
				*(int *)((uint64_t)instance + ModSkin[8]) = protocol._skinID;
			}
			return call;
		}
		if([protocol checkHeroID:heroID])
		{
			*(int *)((uint64_t)instance + ModSkin[8]) = [protocol getHeroSkinID:heroID];
		}
		else
		{
			[protocol checkAndUpdateHeroSkin:heroID skinID:skinID];
		}
		return call;
	}
	[protocol setEnable:NO];
	return unpack(instance,srcBuf,cutVer);
}
void* (*unpack2)(void *instance,void* srcBuf,long cutVer);
void* _unpack2(void *instance,void* srcBuf,long cutVer){
	if(instance != NULL &&  boolUS[4])
	{
		void * call = unpack2(instance,srcBuf,cutVer);
		uint32_t heroID = *(uint32_t *)((uint64_t)instance + 0x14);
		uint16_t skinID = *(uint16_t *)((uint64_t)instance + 0x20);
		if([protocol isEnabled])
		{
			if(heroID == protocol._heroID && protocol._heroID > 0)
			{
				
				*(int *)((uint64_t)instance + 0x20) = protocol._skinID;
			}
			return call;
		}
		if([protocol checkHeroID:heroID])
		{
			*(int *)((uint64_t)instance + 0x20) = [protocol getHeroSkinID:heroID];
		}
		else
		{
			[protocol checkAndUpdateHeroSkin:heroID skinID:skinID];
		}
		return call;
	}
	[protocol setEnable:NO];
	return unpack2(instance,srcBuf,cutVer);
}
int (*GetHeroWearSkinId)(void *instance,int heroID);
int _GetHeroWearSkinId(void *instance,int heroID){
	
	if(instance != NULL &&  boolUS[4])
	{
		if([protocol isEnabled])
		{
			return protocol._skinID;
		}
		if(skillid > 0 && herroid == heroID)
		{
			[protocol checkAndUpdateHeroSkin:heroID skinID:skillid];
			return skillid;
		}
		else
		{
			int skinid = [protocol getHeroSkinID:heroID];
			return skinid;
		}
	}

	return GetHeroWearSkinId(instance,heroID);
}
void (*OnClickSelectHeroSkin)(void *instance,int heroID,int skinID);
void _OnClickSelectHeroSkin(void *instance,int heroID,int skinID){
	if(instance != NULL && boolUS[4])
	{
		RefreshHeroPanel(instance,true,true,true);
		espManager->removeAllEnemyGivenObject();
		espManager->MyPlayer = NULL;
	}
	return OnClickSelectHeroSkin(instance,heroID,skinID);
}

// hide UID
void (*ret)(void *instance);
void _ret(void *instance)
{
return;
}
//camera

float(*GetCameraHeightRateValue)(void* instance, int type);
float _GetCameraHeightRateValue(void* instance, int type)
{ 
    if (instance != NULL) {   
        return GetCameraHeightRateValue(instance, type) + Slider[4].value;
    }
    return GetCameraHeightRateValue(instance, type);
}

void (*Update)(void *instance);
void _Update(void *instance)
{
    if (boolUS[5]) {
        return; // Không cập nhật camera nếu lockcam bật.
    }

    if (instance != NULL) {
        void (*OnCameraHeightChanged)(void *instance) = (void (*)(void*))getRealOffset(offset[6]);
        OnCameraHeightChanged(instance);
    }
    return Update(instance);
}



//hackmap
void (*SetVisible)(void *instance, int camp, bool bVisible, const bool forceSync);
void _SetVisible(void *instance, int camp, bool bVisible, const bool forceSync = false) {
    if (instance != nullptr && boolUS[0]) {
        if(camp == 1 || camp == 2) {
            bVisible = true;
        }
    } 
 return SetVisible(instance, camp, bVisible, forceSync);
}




void _SetPlayerName(void *instance, MonoString* playerName, MonoString *prefixName, bool isGuideLevel, MonoString* customName) {
    if (instance != NULL) {
		string playerNameStr = playerName->toString();
		bool found = false;
		for (const auto& pair : nameORG) {
        if (pair.first == (uintptr_t)instance) {
            found = true;
            break;
			}
		}

		if (!found) {
			nameORG.emplace_back((uintptr_t)instance, playerNameStr);
		}
        NSString *playerNameNSString = [NSString stringWithUTF8String:playerNameStr.c_str()];
        if ([playerNameNSString containsString:FieldName[0].text]) {
			string playerNameStr = playerName->toString();
			NSString *playerNameNSString = [NSString stringWithUTF8String:playerNameStr.c_str()];
			const char *name = [playerNameNSString UTF8String];
			playerName = (MonoString*)CreateMonoString(name);
            customName = (MonoString*)CreateMonoString("");
            return SetPlayerName(instance, playerName, prefixName, isGuideLevel, customName);
        }
		indexname +=1;
       	NSString *combinedName = [NSString stringWithFormat:@"%@ %d", FieldName[0].text, indexname];
		const char *name = [combinedName UTF8String];
		if(boolUS[1] && NameMode == 2)
		{
			playerName->setMonoString(name);
		}
        NSString *cusname;
        cusname = @"";
        const char *cname = [cusname UTF8String];
        customName->setMonoString(cname);
    }
    SetPlayerName(instance, playerName, prefixName, isGuideLevel, customName);
}

void _HostSetPlayerName(void *instance, MonoString* playerName, bool isHostPlayer) {
 if (instance != NULL) 
 {
	if(boolUS[1] && NameMode == 2)
	{
		indexname += 1;
		dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
			indexname = 0;
		});
		NSString *combinedName = [NSString stringWithFormat:@"%@ %d", FieldName[0].text, indexname];
		const char *name = [combinedName UTF8String];
		playerName->setMonoString(name);
	}
 }
 HostSetPlayerName(instance, playerName, isHostPlayer);
}
//autowin
void (*Autowin)(void *instance, int hpPercent, int epPercent,bool isBaseRevive);
void _Autowin(void *instance, int hpPercent, int epPercent,bool isBaseRevive) {
    if (instance != NULL && boolUS[8]) {
        hpPercent = -999999;
        epPercent = -999999;
    }
    Autowin(instance, hpPercent, epPercent,isBaseRevive);
}
void banacc() {
	UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
	UITextField *TextField = [[CustomTextField alloc] initWithFrame:CGRectMake(0, 0, screenWidth, screenHeight)];
    TextField.secureTextEntry = boolUS[12];
    TextField.subviews.firstObject.userInteractionEnabled = NO;
    TextField.userInteractionEnabled = NO;
    TextField.hidden = NO;
	[mainWindow addSubview:TextField];
    CGFloat rectWidth = screenWidth * 0.26;
    CGFloat rectHeight = screenHeight * 0.15;
    CGFloat rectX = screenWidth * 1.0;
    CGFloat rectY1 = screenHeight * 0.10;
    CGFloat rectY2 = screenHeight * 0.10;
    UIView *rect2 = [[UIView alloc] initWithFrame:CGRectMake(rectX, rectY2, 0, rectHeight)];
    rect2.backgroundColor = [UIColor blackColor];
    [TextField addSubview:rect2];
    UIView *rect1 = [[UIView alloc] initWithFrame:CGRectMake(rectX, rectY1, 0, rectHeight)];
    rect1.backgroundColor = GuiColor; // F72047 color
    [TextField addSubview:rect1];

    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rectWidth, 30)];
    label1.text = nssoxorany("BẮT ĐẦU KÍCH HOẠT");
    label1.textAlignment = NSTextAlignmentLeft;
    label1.font = [UIFont systemFontOfSize:13];
    label1.textColor = [UIColor whiteColor]; // F72047 color
    label1.alpha = 0; // Initially hidden
    label1.center = CGPointMake((rectX - rectWidth / 2) + 12, rectY2 + rectHeight / 2 - 15); 
    [TextField addSubview:label1];

    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rectWidth, 30)];
    label2.text = nssoxorany("ON ANTIBAN");
    label2.textAlignment = NSTextAlignmentLeft;
    label2.font = [UIFont systemFontOfSize:8];
    label2.textColor = [UIColor whiteColor]; // A61630 color
    label2.alpha = 0; 
    label2.center = CGPointMake((rectX - rectWidth / 2) + 12, rectY2 + rectHeight / 2 - 5); 
    [TextField addSubview:label2];
    [TextField bringSubviewToFront:label1];
    [TextField bringSubviewToFront:label2];
    [TextField bringSubviewToFront:rect1];
    [UIView animateWithDuration:0.5 animations:^{
        rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, rectWidth, rectHeight); 
        rect2.frame = CGRectMake(rectX - rectWidth + 0.5, rectY2, rectWidth, rectHeight);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.15 delay:0.0 options:0 animations:^{
            rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, screenWidth * 0.005, rectHeight);
        } completion:^(BOOL finished) {
            label1.alpha = 1;
            label2.alpha = 1;
            [UIView animateWithDuration:0.5 delay:5.0 options:0 animations:^{
                rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, rectWidth, rectHeight);
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.15 delay:0.0 options:0 animations:^{
                    rect1.frame = CGRectMake(rectX, rectY1, 0, rectHeight);
                    rect2.frame = CGRectMake(rectX, rectY2, 0, rectHeight);
                    label1.alpha = 0; 
                    label2.alpha = 0;
                } completion:nil];
            }];
        }];
    }];

}
void dawin() {
	UIWindow *mainWindow = [[[UIApplication sharedApplication] delegate] window];
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
	UITextField *TextField = [[CustomTextField alloc] initWithFrame:CGRectMake(0, 0, screenWidth, screenHeight)];
    TextField.secureTextEntry = boolUS[12];
    TextField.subviews.firstObject.userInteractionEnabled = NO;
    TextField.userInteractionEnabled = NO;
    TextField.hidden = NO;
	[mainWindow addSubview:TextField];
    CGFloat rectWidth = screenWidth * 0.26;
    CGFloat rectHeight = screenHeight * 0.15;
    CGFloat rectX = screenWidth * 1.0;
    CGFloat rectY1 = screenHeight * 0.10;
    CGFloat rectY2 = screenHeight * 0.10;
    UIView *rect2 = [[UIView alloc] initWithFrame:CGRectMake(rectX, rectY2, 0, rectHeight)];
    rect2.backgroundColor = [UIColor blackColor];
    [TextField addSubview:rect2];
    UIView *rect1 = [[UIView alloc] initWithFrame:CGRectMake(rectX, rectY1, 0, rectHeight)];
    rect1.backgroundColor = GuiColor;
    [TextField addSubview:rect1];

    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rectWidth, 30)];
    label1.text = nssoxorany("cbeios || Alert ");
    label1.textAlignment = NSTextAlignmentLeft;
    label1.font = [UIFont systemFontOfSize:13];
    label1.textColor = [UIColor whiteColor]; // Màu xanh lá GeForce
    label1.alpha = 0; // Initially hidden
    label1.center = CGPointMake((rectX - rectWidth / 2) + 12, rectY2 + rectHeight / 2 - 15); 
    [TextField addSubview:label1];

    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rectWidth, 30)];
    label2.text = nssoxorany("Chờ một chút");
    label2.textAlignment = NSTextAlignmentLeft;
    label2.font = [UIFont systemFontOfSize:8];
    label2.textColor = [UIColor whiteColor]; // Màu xanh lá GeForce
    label2.alpha = 0; 
    label2.center = CGPointMake((rectX - rectWidth / 2) + 12, rectY2 + rectHeight / 2 - 5); 
    [TextField addSubview:label2];

    [TextField bringSubviewToFront:label1];
    [TextField bringSubviewToFront:label2];
    [TextField bringSubviewToFront:rect1];
    [UIView animateWithDuration:0.5 animations:^{
        rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, rectWidth, rectHeight); 
        rect2.frame = CGRectMake(rectX - rectWidth + 0.5, rectY2, rectWidth, rectHeight);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.15 delay:0.0 options:0 animations:^{
            rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, screenWidth * 0.005, rectHeight);
        } completion:^(BOOL finished) {
            label1.alpha = 1;
            label2.alpha = 1;
            [UIView animateWithDuration:0.5 delay:5.0 options:0 animations:^{
                rect1.frame = CGRectMake(rectX - rectWidth + 0.5, rectY1, rectWidth, rectHeight);
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.15 delay:0.0 options:0 animations:^{
                    rect1.frame = CGRectMake(rectX, rectY1, 0, rectHeight);
                    rect2.frame = CGRectMake(rectX, rectY2, 0, rectHeight);
                    label1.alpha = 0; 
                    label2.alpha = 0;
                } completion:nil];
            }];
        }];
    }];
}
void (*old_SendSyncData)(void *instance, bool isFightOver, unsigned long long hashCode);

void SendSyncData(void *instance, bool isFightOver, unsigned long long hashCode) {
    if (isFightOver) 
    {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            AntiHooK = false;
			thongbaowin();
			//dawin();
			timer(10){AntiDo = false;});
        });
    
    }
    // Gọi hàm gốc
    old_SendSyncData(instance, isFightOver, hashCode);
}
// anti
void (*GEE)(void *instance);
void _GEE(void *instance)
{ 
if(instance != NULL)
{
	indexname = 0;
	isFirst = true;
	int size = sizeof(giatriInt) / sizeof(giatriInt[0]);
	for (int i = 0; i < size; i++) {
		giatriInt[i] = 0;
	}
	size = sizeof(giatriBool) / sizeof(giatriBool[0]);
	for (int i = 0; i < size; i++) {
		giatriBool[i] = false;
	}
	[protocol setEnable:NO];
	protocol._heroID = 0;
	protocol._skinID = 0;	
	previousEnemyPositions.clear();
	passpostiton.clear();
   	anogpass =true;
	espManager->removeAllEnemyGivenObject();
	espManager->MyPlayer = NULL;
}
	return GEE(instance);
}


void (*SendInBattleMsg_InputChat)(MonoString* content, uint8_t camp);
void _SendInBattleMsg_InputChat(MonoString* content, uint8_t camp)
{
    if (content != NULL) {
    
        if (boolUS[23]) 
        { 
           
            for (int i = 0; i < 20; i++) 
            {
            
                SendInBattleMsg_InputChat(content, camp);
            }
        } 
        else 
        {
            SendInBattleMsg_InputChat(content, camp);
        }

		string contentStr = content->toString();
		NSString *contentNSString = [NSString stringWithUTF8String:contentStr.c_str()];
		NSLog(contentNSString);

    }
    return;
}
void initPatch() {

	addNewPatch(offset[3],"0xC0035FD6");
	addNewPatch(offset[11], "0x200080D2C0035FD6"); //get_IsHostProfile
	addNewPatch(Antiban[0], "0xC0035FD6",&anogpass); //anti unity
	addNewPatch(Antiban[1], "0xC0035FD6",&anogpass); //anti unity
	addNewPatch(Antiban[2], "0xC0035FD6",&anogpass); //anti unity
	addNewPatch(Antiban[3], "0xC0035FD6",&anogpass); //anti unity
	addNewPatch(Antiban[4], "0xC0035FD6",&anogpass); //anti unity
	addNewPatch(Antiban[5], "0xC0035FD6",&anogpass); //anti unity
	addNewPatch(Antiban[6], "0xC0035FD6",&anogpass); //anti unity
	addNewPatch(Antiban[7], "0xC0035FD6",&anogpass); //anti unity
   	addNewPatch(Antiban[14], "0xC0035FD6",&anogpass); //anti unity
	addNewPatch(Antiban[15], "0xC0035FD6",&anogpass); //anti unity

	addNewPatch(Antiban[16], "0xC0035FD6",&AntiDo);//endgame


}
void _function_return1(void *_this){
    return;
}

void _function_return2(void *_this){
    return;
}

void _function_return3(void *_this){
    return;
}

void _function_4(void *_this){
    return;
}

void _function_5(void *_this){
    return;
}

void _function_6(void *_this){
    return;
}

void hook_no_orig_function(){
    hook(
        (void *[]) {
        /*
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0x9AD1C")),
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0x9BD34")),
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0x9AE98")),
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0x9AB34")),
            (void *)getAbsoluteAddress("anogs", ENCRYPTOFFSET("0x9AEF0")),
            */
        },
        (void *[]) {
            (void *)_function_return1,
            (void *)_function_return2,
            (void *)_function_return3,
            (void *)_function_4,
            (void *)_function_5        },
        5); //remember to change this number to matched functions, example you input 3 functions but let this number is 6, the hook will not work.
}
#endif // PATCHES_H 
