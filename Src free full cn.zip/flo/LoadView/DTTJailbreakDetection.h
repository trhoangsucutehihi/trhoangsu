#import <UIKit/UIKit.h>

@interface DTTJailbreakDetection : NSObject

+ (BOOL)isJailbroken;

@end