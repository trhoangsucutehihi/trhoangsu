#include "oxorany.h"
#include <stddef.h>

size_t& _lxy_oxor_any_::X() {
	static size_t x = 0; 
	return x;
}

size_t& _lxy_oxor_any_::Y() {
	static size_t y = 0; 
	return y;
}
