#include "hack/Vector3.h"
#include "hack/Vector2.h"
#include "hack/Quaternion.h"
#include "hack/Color.h"

#define LOG_TAG  "PusexPrivate.xyz"

float NormalizeAngle(float angle) {
    while (angle > 360)
        angle -= 360;
    while (angle < 0)
        angle += 360;
    return angle;
}

Vector3 NormalizeAngles(Vector3 angles) {
    angles.x = NormalizeAngle(angles.x);
    angles.y = NormalizeAngle(angles.y);
    angles.z = NormalizeAngle(angles.z);
    return angles;
}

Vector3 ToEulerRad(Quaternion q1) {
    constexpr float rad2Deg = 360.0 / (M_PI * 2.0); // Đổi tên hằng số để tránh xung đột

    float sqw = q1.w * q1.w;
    float sqx = q1.x * q1.x;
    float sqy = q1.y * q1.y;
    float sqz = q1.z * q1.z;
    float unit = sqx + sqy + sqz + sqw;
    float test = q1.x * q1.w - q1.y * q1.z;
    Vector3 v;

    if (test > 0.4995 * unit) {
        v.y = 2.0 * atan2f(q1.y, q1.x);
        v.x = M_PI / 2.0;
        v.z = 0;
        return NormalizeAngles(v * rad2Deg);
    }
    if (test < -0.4995 * unit) {
        v.y = -2.0 * atan2f(q1.y, q1.x);
        v.x = -M_PI / 2.0;
        v.z = 0;
        return NormalizeAngles(v * rad2Deg);
    }
    Quaternion q(q1.w, q1.z, q1.x, q1.y);
    v.y = atan2f(2.0 * q.x * q.w + 2.0 * q.y * q.z, 1 - 2.0 * (q.z * q.z + q.w * q.w)); // yaw
    v.x = asinf(2.0 * (q.x * q.z - q.w * q.y)); // pitch
    v.z = atan2f(2.0 * q.x * q.y + 2.0 * q.z * q.w, 1 - 2.0 * (q.y * q.y + q.z * q.z)); // roll
    return NormalizeAngles(v * rad2Deg);
}

Quaternion GetRotationToLocation(Vector3 targetLocation, float y_bias, Vector3 myLoc) {
    return Quaternion::LookRotation((targetLocation + Vector3(0, y_bias, 0)) - myLoc, Vector3(0, 1, 0));
}

template <typename T>
struct monoArray {
    void* klass;
    void* monitor;
    void* bounds;
    int max_length;
    void* vector[1];
    int getLength() {
        return max_length;
    }
    T getPointer() {
        return (T)vector;
    }
};

template <typename T>
struct monoList {
    void* unk0;
    void* unk1;
    monoArray<T>* items;
    int size;
    int version;

    T getItems() {
        return items->getPointer();
    }

    int getSize() {
        return size;
    }

    int getVersion() {
        return version;
    }
};

template <typename K, typename V>
struct monoDictionary {
    void* unk0;
    void* unk1;
    monoArray<int**>* table;
    monoArray<void**>* linkSlots;
    monoArray<K>* keys;
    monoArray<V>* values;
    int touchedSlots;
    int emptySlot;
    int size;

    K getKeys() {
        return keys->getPointer();
    }

    V getValues() {
        return values->getPointer();
    }

    int getNumKeys() {
        return keys->getLength();
    }

    int getNumValues() {
        return values->getLength();
    }

    int getSize() {
        return size;
    }
};

union intfloat {
    int i;
    float f;
};

typedef struct _monoString {
    void* klass;
    void* monitor;
    int length;
    char chars[1];
    int getLength() {
        return length;
    }
    char* getChars() {
        return chars;
    }
} monoString;

typedef struct _StringUnity
{
    void* klass;
    void* monitor;
    int length;
    char chars[1];
    int getLength()
    {
      return length;
    }
    char* getChars()
    {
        return chars;
    }
} StringUnity;
template <typename T>
struct MonoArray
{
    	void* klass;
    	void* monitor;
	    void* bounds;
    	int   max_length;
    	T vector[65535];

    	T &operator [] (int i) 
    	{
        	return vector[i];
    	}

    	const T &operator [] (int i) const 
    	{
        	return vector[i];
    	}

    	bool Contains(T item) 
    	{
        	for (int i = 0; i < max_length; i++)
        	{
            		if(vector[i] == item) return true;
        	}
        	return false;
    	}
};

template<typename T>
using Array = MonoArray<T>;

template<typename T> 
struct MonoList {
    void *klass;
    void *unk1;
    Array<T> *items;
    int size;
    int version;

    T* getItems() {
        return items->getPointer();
    }

    int getSize() {
        return size;
    }

    int getVersion() {
        return version;
    }
};

template<typename TKey, typename TValue> 
struct Dictionary 
{
    struct KeysCollection;
    struct ValueCollection;

    struct Entry
    {
        int hashCode; 
        int next;
        TKey key;
        TValue value;
    };

    void *kass;
    void *monitor;
    Array<int> *buckets;
    Array<Entry> *entries;
    int count;
    int version;
    int freeList;
    int freeCount;
    void* comparer;
    KeysCollection *keys;
    ValueCollection *values;
    void *_syncRoot;

    void* get_Comparer()
    {
        return comparer;
    }

    int get_Count()
    {
        return count;
    }

    KeysCollection get_Keys()
    {
        if(!keys) keys = new KeysCollection(this);
        return (*keys);
    }

    ValueCollection get_Values()
    {
        if(!values) values = new ValueCollection(this);
        return (*values);
    }

    TValue operator [] (TKey key) 
    {
        int i = FindEntry(key);
        if (i >= 0) return (*entries)[i].value;
        return TValue();
    }

    const TValue operator [] (TKey key) const 
    {
        int i = FindEntry(key);
        if (i >= 0) return (*entries)[i].value;
        return TValue();
    }
    
    int FindEntry(TKey key) 
    {
        for (int i = 0; i < count; i++)
        {
            if((*entries)[i].key == key) return i;
        }
        return -1;
    }
    
    bool ContainsKey(TKey key) 
    {
        return FindEntry(key) >= 0;
    }
    
    bool ContainsValue(TValue value) 
    {
        for (int i = 0; i < count; i++)
        {
            if((*entries)[i].hashCode >= 0 && 
                    (*entries)[i].value == value) return true;
        }
        return false;
    }

    bool TryGetValue(TKey key, TValue *value) 
    {
        int i = FindEntry(key);
        if (i >= 0) {
            *value = (*entries)[i].value;
            return true;
        }
        *value = TValue();
        return false;
    }

    TValue GetValueOrDefault(TKey key) 
    {
        int i = FindEntry(key);
        if (i >= 0) {
            return (*entries)[i].value;
        }
        return TValue();
    }

    struct KeysCollection 
    {
        Dictionary *dictionary;

        KeysCollection(Dictionary *dictionary)
        {
            this->dictionary = dictionary;
        }

        TKey operator [] (int i) 
        {
            auto entries = dictionary->entries;
            if(!entries) return TKey();
            return (*entries)[i].key;
        }

        const TKey operator [] (int i) const 
        {
            auto entries = dictionary->entries;
            if(!entries) return TKey();
            return (*entries)[i].key;
        }

        int get_Count()
        {
            return dictionary->get_Count();
        }
    };

    struct ValueCollection 
    {
        Dictionary *dictionary;

        ValueCollection(Dictionary *dictionary)
        {
            this->dictionary = dictionary;
        }

        TValue operator [] (int i) 
        {
            auto entries = dictionary->entries;
            if(!entries) return TValue();
            return (*entries)[i].value;
        }

        const TValue operator [] (int i) const 
        {
            auto entries = dictionary->entries;
            if(!entries) return TValue();
            return (*entries)[i].value;
        }

        int get_Count()
        {
            return dictionary->get_Count();
        }
    };
};
template<typename T>
struct ListView {
    Array<T> *items;
    int size; 
    int capacity; 

    ListView(int initialCapacity) {
        capacity = initialCapacity;
        size = 0;
        items = new Array<T>[capacity]; // Khởi tạo mảng
    }

    T Get(int index) {
        if (index < 0 || index >= size) {
        }
        return items[index];
    }
    int GetSize() {
        return size;
    }
    bool Contains(T item) {
        for (int i = 0; i < size; i++) {
            if (items[i] == item) {
                return true;
            }
        }
        return false;
    }
    bool Remove(T item) {
        for (int i = 0; i < size; i++) {
            if (items[i] == item) {
                for (int j = i; j < size - 1; j++) {
                    items[j] = items[j + 1];
                }
                size--; 
                return true;
            }
        }
        return false; 
    }
    T operator[](int index) {
        return Get(index);
    }
    int Count() {
        return GetSize();
    }
};
/*
Get the real value of an ObscuredInt.
Parameters:
    - location: the location of the ObscuredInt
*/
int GetObscuredIntValue(uint64_t location) {
    int cryptoKey = *(int*)location;
    int obfuscatedValue = *(int*)(location + 0x4);

    return obfuscatedValue ^ cryptoKey;
}

int GetObscuredBoolValue(uint64_t location) {
    int cryptoKey = *(int*)(location + 0x8);
    int obfuscatedValue = *(int*)(location + 0xC);
    obfuscatedValue ^= cryptoKey;
    return obfuscatedValue;
}

/*
Set the real value of an ObscuredInt.
Parameters:
    - location: the location of the ObscuredInt
    - value: the value we're setting the ObscuredInt to
*/
void SetObscuredIntValue(uint64_t location, int value) {
    int cryptoKey = *(int*)location;

    *(int*)(location + 0x4) = value ^ cryptoKey;
}

/*
Get the real value of an ObscuredFloat.
Parameters:
    - location: the location of the ObscuredFloat
*/
float GetObscuredFloatValue(uint64_t location) {
    int cryptoKey = *(int*)location;
    int obfuscatedValue = *(int*)(location + 0x4);

    /* use this intfloat to set the integer representation of our parameter value, which will also set the float value */
    intfloat IF;
    IF.i = obfuscatedValue ^ cryptoKey;

    return IF.f;
}

/*
Set the real value of an ObscuredFloat.
Parameters:
    - location: the location of the ObscuredFloat
    - value: the value we're setting the ObscuredFloat to
*/
void SetObscuredFloatValue(uint64_t location, float value) {
    int cryptoKey = *(int*)location;

    /* use this intfloat to get the integer representation of our parameter value */
    intfloat IF;
    IF.f = value;

    /* use this intfloat to generate our hacked ObscuredFloat */
    intfloat IF2;
    IF2.i = IF.i ^ cryptoKey;

    *(float*)(location + 0x4) = IF2.f;
}
